<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Wallet Management — Investment Company</title>

  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet" />

  <!-- Phosphor Icons -->
  <script src="https://unpkg.com/@phosphor-icons/web" defer></script>

  <!-- AOS -->
  <link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css" />

  <!-- QRCode.js -->
  <script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>

  <link rel="stylesheet" href="wallet.css" />
</head>
<body>

  <!-- ===================================================
       SIDEBAR — identical to dashboard.html
  =================================================== -->
  <aside class="sidebar" id="sidebar">
    <div class="sb-blob sb-blob--1"></div>
    <div class="sb-blob sb-blob--2"></div>
    <div class="sb-ring sb-ring--1"></div>

    <div class="sb-logo">
      <span class="logo-dot"></span>
      <span class="logo-text">LOGO</span>
      <button class="sb-collapse-btn" id="sidebarCollapseBtn" aria-label="Collapse sidebar">
        <i class="ph ph-sidebar-simple"></i>
      </button>
    </div>

    <nav class="sb-nav" aria-label="Dashboard navigation">
      <a href="dashboard.html" class="sb-link" data-section="overview">
        <span class="sb-icon"><i class="ph ph-squares-four"></i></span>
        <span class="sb-label">Dashboard</span>
      </a>
      <a href="dashboard.html#portfolio" class="sb-link" data-section="portfolio">
        <span class="sb-icon"><i class="ph ph-chart-pie-slice"></i></span>
        <span class="sb-label">Portfolio</span>
      </a>
      <a href="dashboard.html#investments" class="sb-link" data-section="investments">
        <span class="sb-icon"><i class="ph ph-trend-up"></i></span>
        <span class="sb-label">Investments</span>
      </a>
      <a href="dashboard.html#transactions" class="sb-link" data-section="transactions">
        <span class="sb-icon"><i class="ph ph-arrows-left-right"></i></span>
        <span class="sb-label">Transactions</span>
      </a>
      <a href="wallet.html" class="sb-link active" data-section="wallet">
        <span class="sb-icon"><i class="ph ph-wallet"></i></span>
        <span class="sb-label">Wallet</span>
      </a>
      <a href="dashboard.html#referrals" class="sb-link" data-section="referrals">
        <span class="sb-icon"><i class="ph ph-users-three"></i></span>
        <span class="sb-label">Referrals</span>
      </a>
      <a href="dashboard.html#settings" class="sb-link" data-section="settings">
        <span class="sb-icon"><i class="ph ph-gear"></i></span>
        <span class="sb-label">Settings</span>
      </a>

      <div class="sb-divider"></div>

      <a href="index.html" class="sb-link sb-logout">
        <span class="sb-icon"><i class="ph ph-sign-out"></i></span>
        <span class="sb-label">Logout</span>
      </a>
    </nav>

    <div class="sb-user">
      <div class="sb-avatar">
        <span>JD</span>
        <div class="sb-avatar-ring"></div>
      </div>
      <div class="sb-user-info">
        <span class="sb-user-name">John Doe</span>
        <span class="sb-user-role">Pro Investor</span>
      </div>
    </div>
  </aside>

  <!-- Mobile overlay -->
  <div class="sb-overlay" id="sbOverlay"></div>

  <!-- ===================================================
       MAIN WRAPPER
  =================================================== -->
  <div class="dash-wrapper" id="dashWrapper">

    <!-- ===================================================
         TOP NAVBAR — identical to dashboard.html
    =================================================== -->
    <header class="dash-nav">
      <div class="dn-left">
        <button class="dn-hamburger" id="dnHamburger" aria-label="Toggle sidebar">
          <i class="ph ph-list"></i>
        </button>
        <div class="dn-search-wrap">
          <i class="ph ph-magnifying-glass"></i>
          <input type="search" placeholder="Search..." class="dn-search" id="dnSearch" aria-label="Search" />
        </div>
      </div>

      <div class="dn-right">
        <div class="dn-action-btn" id="notifBtn" aria-label="Notifications" role="button" tabindex="0">
          <i class="ph ph-bell"></i>
          <span class="dn-badge">3</span>
          <div class="dn-dropdown notif-dropdown" id="notifDropdown">
            <div class="dd-header">
              <span>Notifications</span>
              <button class="dd-mark-read">Mark all read</button>
            </div>
            <div class="dd-list">
              <div class="dd-item dd-item--unread">
                <div class="dd-item-icon dd-icon-success"><i class="ph ph-check-circle"></i></div>
                <div class="dd-item-body"><p>Deposit of $2,500 confirmed</p><span>2 min ago</span></div>
              </div>
              <div class="dd-item dd-item--unread">
                <div class="dd-item-icon dd-icon-info"><i class="ph ph-trend-up"></i></div>
                <div class="dd-item-body"><p>Growth Plan profit credited</p><span>1 hr ago</span></div>
              </div>
              <div class="dd-item dd-item--unread">
                <div class="dd-item-icon dd-icon-warn"><i class="ph ph-warning"></i></div>
                <div class="dd-item-body"><p>Verify identity to unlock withdrawals</p><span>Yesterday</span></div>
              </div>
            </div>
          </div>
        </div>

        <div class="dn-action-btn" id="msgBtn" aria-label="Messages" role="button" tabindex="0">
          <i class="ph ph-chat-circle-dots"></i>
          <span class="dn-badge dn-badge--teal">2</span>
        </div>

        <button class="dn-theme-btn" id="themeToggle" aria-label="Toggle theme">
          <i class="ph ph-moon theme-icon-ph"></i>
        </button>

        <div class="dn-profile-wrap" id="profileWrap">
          <button class="dn-profile-btn" id="profileBtn" aria-label="Profile menu" aria-haspopup="true" aria-expanded="false">
            <div class="dn-avatar">JD</div>
            <span class="dn-profile-name">John Doe</span>
            <i class="ph ph-caret-down"></i>
          </button>
          <div class="dn-dropdown profile-dropdown" id="profileDropdown">
            <a href="#" class="dd-profile-item"><i class="ph ph-user"></i> Profile</a>
            <a href="#" class="dd-profile-item"><i class="ph ph-gear"></i> Settings</a>
            <div class="dd-divider"></div>
            <a href="index.html" class="dd-profile-item dd-logout"><i class="ph ph-sign-out"></i> Logout</a>
          </div>
        </div>
      </div>
    </header>

    <!-- ===================================================
         WALLET CONTENT
    =================================================== -->
    <main class="dash-content">

      <!-- =============================================
           SECTION 1 — WALLET BANNER
      ============================================= -->
      <section class="wallet-banner">
        <!-- Background shapes -->
        <div class="wb-blob wb-blob--1"></div>
        <div class="wb-blob wb-blob--2"></div>
        <div class="wb-blob wb-blob--3"></div>
        <div class="wb-ring wb-ring--1"></div>
        <div class="wb-ring wb-ring--2"></div>
        <div class="wb-glow wb-glow--1"></div>
        <div class="wb-glow wb-glow--2"></div>

        <!-- Arc wave at bottom -->
        <div class="wb-wave">
          <svg viewBox="0 0 1440 80" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0,0 C360,80 1080,0 1440,60 L1440,80 L0,80 Z" fill="var(--body-bg)" />
          </svg>
        </div>

        <div class="wb-inner">
          <div class="wb-title-block">
            <div class="wb-page-tag"><i class="ph ph-wallet"></i> Wallet</div>
            <h1 class="wb-title">Wallet <span class="wb-title-accent">Management</span></h1>
            <p class="wb-subtitle">Deposit funds, request withdrawals, and track every transaction in one place.</p>
          </div>

          <!-- Balance overview cards -->
          <div class="wb-balance-cards">

            <div class="wbc-card wbc-card--main" data-aos="fade-up" data-aos-delay="0">
              <div class="wbc-card-glow"></div>
              <div class="wbc-card-ring"></div>
              <div class="wbc-card-shape"></div>
              <div class="wbc-card-icon"><i class="ph ph-wallet"></i></div>
              <span class="wbc-card-label">Available Balance</span>
              <div class="wbc-card-value" data-target="38640" data-prefix="$">$0</div>
              <div class="wbc-card-trend wbc-trend--up"><i class="ph ph-trend-up"></i> +12.4% this month</div>
            </div>

            <div class="wbc-card" data-aos="fade-up" data-aos-delay="80">
              <div class="wbc-card-glow wbc-glow--gold"></div>
              <div class="wbc-card-shape wbc-shape--gold"></div>
              <div class="wbc-card-icon wbc-icon--gold"><i class="ph ph-clock-countdown"></i></div>
              <span class="wbc-card-label">Pending Withdrawals</span>
              <div class="wbc-card-value" data-target="1200" data-prefix="$">$0</div>
              <div class="wbc-card-trend wbc-trend--warn"><i class="ph ph-hourglass"></i> Processing 1-3 days</div>
            </div>

            <div class="wbc-card" data-aos="fade-up" data-aos-delay="160">
              <div class="wbc-card-glow wbc-glow--sky"></div>
              <div class="wbc-card-shape wbc-shape--sky"></div>
              <div class="wbc-card-icon wbc-icon--sky"><i class="ph ph-arrow-circle-down"></i></div>
              <span class="wbc-card-label">Total Deposits</span>
              <div class="wbc-card-value" data-target="52400" data-prefix="$">$0</div>
              <div class="wbc-card-trend wbc-trend--up"><i class="ph ph-trend-up"></i> Lifetime</div>
            </div>

            <div class="wbc-card" data-aos="fade-up" data-aos-delay="240">
              <div class="wbc-card-glow wbc-glow--red"></div>
              <div class="wbc-card-shape wbc-shape--red"></div>
              <div class="wbc-card-icon wbc-icon--red"><i class="ph ph-arrow-circle-up"></i></div>
              <span class="wbc-card-label">Total Withdrawals</span>
              <div class="wbc-card-value" data-target="13760" data-prefix="$">$0</div>
              <div class="wbc-card-trend wbc-trend--neutral"><i class="ph ph-minus"></i> Lifetime</div>
            </div>

          </div>
        </div>
      </section>

      <!-- =============================================
           SECTION 2 — DEPOSIT / WITHDRAW TABS
      ============================================= -->
      <section class="wallet-main-section" data-aos="fade-up">

        <!-- Diagonal background shape behind tab area -->
        <div class="wms-diag wms-diag--1"></div>
        <div class="wms-diag wms-diag--2"></div>
        <div class="wms-blob wms-blob--1"></div>
        <div class="wms-ring wms-ring--1"></div>

        <!-- Tab Switcher -->
        <div class="wallet-tab-bar">
          <div class="wtb-track">
            <div class="wtb-pill" id="wtbPill"></div>
            <button class="wtb-btn active" data-tab="deposit" id="tabDepositBtn">
              <i class="ph ph-arrow-circle-down"></i>
              <span>Deposit</span>
            </button>
            <button class="wtb-btn" data-tab="withdraw" id="tabWithdrawBtn">
              <i class="ph ph-arrow-circle-up"></i>
              <span>Withdraw</span>
            </button>
          </div>
        </div>

        <!-- ================================
             DEPOSIT PANEL
        ================================ -->
        <div class="wallet-panel wallet-panel--active" id="depositPanel">

          <!-- Deposit methods grid -->
          <div class="wm-methods-head">
            <h2 class="wm-section-title">Choose Deposit Method</h2>
            <p class="wm-section-sub">Select how you would like to fund your account</p>
          </div>

          <div class="wm-methods-grid" id="depositMethodsGrid">

            <div class="wm-method-card" data-method="crypto" data-name="Crypto Deposit" tabindex="0">
              <div class="wm-method-glow"></div>
              <div class="wm-method-blob"></div>
              <div class="wm-method-icon wm-icon--teal"><i class="ph ph-currency-btc"></i></div>
              <div class="wm-method-body">
                <strong>Crypto Deposit</strong>
                <span>Any supported crypto asset</span>
              </div>
              <button class="wm-method-btn">Select <i class="ph ph-arrow-right"></i></button>
            </div>

            <div class="wm-method-card" data-method="bank" data-name="Bank Transfer" tabindex="0">
              <div class="wm-method-glow wm-glow--sky"></div>
              <div class="wm-method-blob wm-blob--sky"></div>
              <div class="wm-method-icon wm-icon--sky"><i class="ph ph-bank"></i></div>
              <div class="wm-method-body">
                <strong>Bank Transfer</strong>
                <span>Wire or ACH transfer</span>
              </div>
              <button class="wm-method-btn wm-btn--sky">Select <i class="ph ph-arrow-right"></i></button>
            </div>

            <div class="wm-method-card" data-method="usdt-trc20" data-name="USDT TRC20" tabindex="0">
              <div class="wm-method-glow wm-glow--green"></div>
              <div class="wm-method-blob wm-blob--green"></div>
              <div class="wm-method-icon wm-icon--green"><i class="ph ph-coins"></i></div>
              <div class="wm-method-body">
                <strong>USDT TRC20</strong>
                <span>Tron network USDT</span>
              </div>
              <button class="wm-method-btn wm-btn--green">Select <i class="ph ph-arrow-right"></i></button>
            </div>

            <div class="wm-method-card" data-method="usdt-erc20" data-name="USDT ERC20" tabindex="0">
              <div class="wm-method-glow wm-glow--purple"></div>
              <div class="wm-method-blob wm-blob--purple"></div>
              <div class="wm-method-icon wm-icon--purple"><i class="ph ph-coins"></i></div>
              <div class="wm-method-body">
                <strong>USDT ERC20</strong>
                <span>Ethereum network USDT</span>
              </div>
              <button class="wm-method-btn wm-btn--purple">Select <i class="ph ph-arrow-right"></i></button>
            </div>

            <div class="wm-method-card" data-method="bitcoin" data-name="Bitcoin" tabindex="0">
              <div class="wm-method-glow wm-glow--gold"></div>
              <div class="wm-method-blob wm-blob--gold"></div>
              <div class="wm-method-icon wm-icon--gold"><i class="ph ph-currency-btc"></i></div>
              <div class="wm-method-body">
                <strong>Bitcoin</strong>
                <span>BTC — Bitcoin network</span>
              </div>
              <button class="wm-method-btn wm-btn--gold">Select <i class="ph ph-arrow-right"></i></button>
            </div>

            <div class="wm-method-card" data-method="ethereum" data-name="Ethereum" tabindex="0">
              <div class="wm-method-glow wm-glow--indigo"></div>
              <div class="wm-method-blob wm-blob--indigo"></div>
              <div class="wm-method-icon wm-icon--indigo"><i class="ph ph-currency-eth"></i></div>
              <div class="wm-method-body">
                <strong>Ethereum</strong>
                <span>ETH — Ethereum network</span>
              </div>
              <button class="wm-method-btn wm-btn--indigo">Select <i class="ph ph-arrow-right"></i></button>
            </div>

            <div class="wm-method-card" data-method="paypal" data-name="PayPal" tabindex="0">
              <div class="wm-method-glow wm-glow--sky"></div>
              <div class="wm-method-blob wm-blob--sky"></div>
              <div class="wm-method-icon wm-icon--sky"><i class="ph ph-paypal-logo"></i></div>
              <div class="wm-method-body">
                <strong>PayPal</strong>
                <span>Fast &amp; secure payment</span>
              </div>
              <button class="wm-method-btn wm-btn--sky">Select <i class="ph ph-arrow-right"></i></button>
            </div>

            <div class="wm-method-card" data-method="stripe" data-name="Credit / Debit Card" tabindex="0">
              <div class="wm-method-glow wm-glow--teal"></div>
              <div class="wm-method-blob"></div>
              <div class="wm-method-icon wm-icon--teal"><i class="ph ph-credit-card"></i></div>
              <div class="wm-method-body">
                <strong>Credit / Debit Card</strong>
                <span>Visa, Mastercard, Amex</span>
              </div>
              <button class="wm-method-btn">Select <i class="ph ph-arrow-right"></i></button>
            </div>

          </div>

          <!-- Deposit Form (shown after method selection) -->
          <div class="wm-form-area" id="depositFormArea">

            <div class="wm-form-header">
              <button class="wm-back-btn" id="depositBackBtn">
                <i class="ph ph-arrow-left"></i> Back
              </button>
              <div class="wm-form-method-label">
                <i class="ph ph-circle-fill wm-method-dot" id="depositMethodDot"></i>
                <span id="depositMethodLabel">Deposit</span>
              </div>
            </div>

            <div class="wm-form-grid">

              <!-- Left: Form + QR -->
              <div class="wm-form-left">

                <!-- QR Panel (crypto only) -->
                <div class="wm-qr-panel" id="depositQrPanel">
                  <div class="wm-qr-panel-shapes">
                    <div class="wm-qr-blob"></div>
                    <div class="wm-qr-ring"></div>
                  </div>
                  <div class="wm-qr-title">Scan to Deposit</div>
                  <div class="wm-qr-box" id="depositQrCode"></div>
                  <div class="wm-qr-addr-wrap">
                    <input type="text" class="wm-qr-addr-input" id="depositQrAddr" readonly
                      value="bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh" aria-label="Wallet address" />
                    <button class="wm-qr-copy-btn" id="depositCopyAddr" aria-label="Copy address">
                      <i class="ph ph-copy" id="depositCopyIcon"></i>
                    </button>
                  </div>
                  <div class="wm-qr-note"><i class="ph ph-info"></i> Send only to this address. Wrong network = lost funds.</div>
                </div>

                <!-- Deposit Form -->
                <form class="wm-form" id="depositForm" novalidate>
                  <div class="wm-field-group">
                    <label class="wm-label" for="depositAmount">Deposit Amount</label>
                    <div class="wm-input-wrap">
                      <span class="wm-input-prefix"><i class="ph ph-currency-dollar"></i></span>
                      <input type="number" id="depositAmount" class="wm-input" placeholder="0.00" min="50" step="0.01" required />
                    </div>
                    <span class="wm-field-hint">Minimum deposit: $50.00</span>
                  </div>

                  <div class="wm-field-group">
                    <label class="wm-label" for="depositCurrency">Select Currency</label>
                    <div class="wm-select-wrap">
                      <select id="depositCurrency" class="wm-select">
                        <option value="USD">USD — US Dollar</option>
                        <option value="BTC">BTC — Bitcoin</option>
                        <option value="ETH">ETH — Ethereum</option>
                        <option value="USDT">USDT — Tether</option>
                      </select>
                      <i class="ph ph-caret-down wm-select-caret"></i>
                    </div>
                  </div>

                  <div class="wm-field-group" id="depositWalletField">
                    <label class="wm-label" for="depositWallet">Your Wallet Address</label>
                    <div class="wm-input-wrap">
                      <span class="wm-input-prefix"><i class="ph ph-wallet"></i></span>
                      <input type="text" id="depositWallet" class="wm-input" placeholder="Enter your wallet address" />
                    </div>
                  </div>

                  <div class="wm-field-group">
                    <label class="wm-label" for="depositProof">Upload Payment Proof <span class="wm-optional">(optional)</span></label>
                    <div class="wm-upload-area" id="depositUploadArea">
                      <i class="ph ph-cloud-arrow-up"></i>
                      <span>Drag &amp; drop or <strong>browse</strong></span>
                      <small>PNG, JPG, PDF up to 5MB</small>
                      <input type="file" id="depositProof" accept="image/*,.pdf" class="wm-upload-input" aria-label="Upload proof" />
                    </div>
                    <div class="wm-upload-preview" id="depositUploadPreview"></div>
                  </div>

                  <button type="submit" class="wm-confirm-btn" id="depositSubmitBtn">
                    <span class="wm-btn-label"><i class="ph ph-arrow-circle-down"></i> Confirm Deposit</span>
                    <span class="wm-btn-spinner" hidden><i class="ph ph-spinner wm-spin"></i> Processing…</span>
                  </button>
                </form>
              </div>

              <!-- Right: Summary card -->
              <div class="wm-form-right">
                <div class="wm-summary-card" id="depositSummaryCard">
                  <div class="wm-summary-glow"></div>
                  <div class="wm-summary-blob wm-summary-blob--1"></div>
                  <div class="wm-summary-ring"></div>

                  <div class="wm-summary-title">
                    <i class="ph ph-receipt"></i> Deposit Summary
                  </div>

                  <div class="wm-summary-rows">
                    <div class="wm-summary-row">
                      <span>Amount</span>
                      <strong id="sumDepositAmount">$0.00</strong>
                    </div>
                    <div class="wm-summary-row">
                      <span>Processing Fee</span>
                      <strong id="sumDepositFee">$0.00</strong>
                    </div>
                    <div class="wm-summary-divider"></div>
                    <div class="wm-summary-row wm-summary-total">
                      <span>Total Credited</span>
                      <strong id="sumDepositTotal">$0.00</strong>
                    </div>
                  </div>

                  <div class="wm-summary-note">
                    <i class="ph ph-shield-check"></i>
                    Funds typically arrive within 15–30 minutes after confirmation.
                  </div>

                  <!-- Trust badges -->
                  <div class="wm-trust-badges">
                    <div class="wm-trust-badge"><i class="ph ph-lock"></i> SSL Secured</div>
                    <div class="wm-trust-badge"><i class="ph ph-shield-check"></i> 256-bit Encrypted</div>
                    <div class="wm-trust-badge"><i class="ph ph-check-circle"></i> KYC Verified</div>
                  </div>
                </div>
              </div>

            </div>
          </div>

        </div>

        <!-- ================================
             WITHDRAW PANEL
        ================================ -->
        <div class="wallet-panel" id="withdrawPanel">

          <!-- Withdraw methods grid -->
          <div class="wm-methods-head">
            <h2 class="wm-section-title">Choose Withdrawal Method</h2>
            <p class="wm-section-sub">Select where you want to receive your funds</p>
          </div>

          <div class="wm-methods-grid" id="withdrawMethodsGrid">

            <div class="wm-method-card" data-method="crypto-wallet" data-name="Crypto Wallet" tabindex="0">
              <div class="wm-method-glow"></div>
              <div class="wm-method-blob"></div>
              <div class="wm-method-icon wm-icon--teal"><i class="ph ph-currency-btc"></i></div>
              <div class="wm-method-body">
                <strong>Crypto Wallet</strong>
                <span>Withdraw to any wallet</span>
              </div>
              <button class="wm-method-btn">Select <i class="ph ph-arrow-right"></i></button>
            </div>

            <div class="wm-method-card" data-method="bank-wd" data-name="Bank Transfer" tabindex="0">
              <div class="wm-method-glow wm-glow--sky"></div>
              <div class="wm-method-blob wm-blob--sky"></div>
              <div class="wm-method-icon wm-icon--sky"><i class="ph ph-bank"></i></div>
              <div class="wm-method-body">
                <strong>Bank Transfer</strong>
                <span>Wire to your bank account</span>
              </div>
              <button class="wm-method-btn wm-btn--sky">Select <i class="ph ph-arrow-right"></i></button>
            </div>

            <div class="wm-method-card" data-method="paypal-wd" data-name="PayPal" tabindex="0">
              <div class="wm-method-glow wm-glow--sky"></div>
              <div class="wm-method-blob wm-blob--sky"></div>
              <div class="wm-method-icon wm-icon--sky"><i class="ph ph-paypal-logo"></i></div>
              <div class="wm-method-body">
                <strong>PayPal</strong>
                <span>Send to PayPal account</span>
              </div>
              <button class="wm-method-btn wm-btn--sky">Select <i class="ph ph-arrow-right"></i></button>
            </div>

            <div class="wm-method-card" data-method="usdt-wd" data-name="USDT" tabindex="0">
              <div class="wm-method-glow wm-glow--green"></div>
              <div class="wm-method-blob wm-blob--green"></div>
              <div class="wm-method-icon wm-icon--green"><i class="ph ph-coins"></i></div>
              <div class="wm-method-body">
                <strong>USDT</strong>
                <span>TRC20 or ERC20</span>
              </div>
              <button class="wm-method-btn wm-btn--green">Select <i class="ph ph-arrow-right"></i></button>
            </div>

            <div class="wm-method-card" data-method="btc-wd" data-name="Bitcoin" tabindex="0">
              <div class="wm-method-glow wm-glow--gold"></div>
              <div class="wm-method-blob wm-blob--gold"></div>
              <div class="wm-method-icon wm-icon--gold"><i class="ph ph-currency-btc"></i></div>
              <div class="wm-method-body">
                <strong>Bitcoin</strong>
                <span>BTC — Bitcoin network</span>
              </div>
              <button class="wm-method-btn wm-btn--gold">Select <i class="ph ph-arrow-right"></i></button>
            </div>

          </div>

          <!-- Withdraw Form (shown after method selection) -->
          <div class="wm-form-area" id="withdrawFormArea">

            <div class="wm-form-header">
              <button class="wm-back-btn" id="withdrawBackBtn">
                <i class="ph ph-arrow-left"></i> Back
              </button>
              <div class="wm-form-method-label">
                <i class="ph ph-circle-fill wm-method-dot wm-dot--red" id="withdrawMethodDot"></i>
                <span id="withdrawMethodLabel">Withdraw</span>
              </div>
            </div>

            <div class="wm-form-grid">

              <!-- Left: Form -->
              <div class="wm-form-left">
                <form class="wm-form" id="withdrawForm" novalidate>

                  <div class="wm-field-group">
                    <label class="wm-label" for="withdrawAmount">Withdrawal Amount</label>
                    <div class="wm-input-wrap">
                      <span class="wm-input-prefix"><i class="ph ph-currency-dollar"></i></span>
                      <input type="number" id="withdrawAmount" class="wm-input" placeholder="0.00" min="100" step="0.01" required />
                    </div>
                    <span class="wm-field-hint">Minimum withdrawal: $100.00 | Available: <strong>$38,640.00</strong></span>
                  </div>

                  <div class="wm-field-group">
                    <label class="wm-label" for="withdrawAddress">Destination Address / Account</label>
                    <div class="wm-input-wrap">
                      <span class="wm-input-prefix"><i class="ph ph-map-pin"></i></span>
                      <input type="text" id="withdrawAddress" class="wm-input" placeholder="Wallet address or account number" required />
                    </div>
                  </div>

                  <div class="wm-field-group" id="withdrawNetworkField">
                    <label class="wm-label" for="withdrawNetwork">Network</label>
                    <div class="wm-select-wrap">
                      <select id="withdrawNetwork" class="wm-select">
                        <option value="bitcoin">Bitcoin (BTC)</option>
                        <option value="ethereum">Ethereum (ERC20)</option>
                        <option value="tron">Tron (TRC20)</option>
                        <option value="bnb">BNB Smart Chain (BEP20)</option>
                      </select>
                      <i class="ph ph-caret-down wm-select-caret"></i>
                    </div>
                  </div>

                  <div class="wm-field-group">
                    <label class="wm-label" for="withdrawNote">Note <span class="wm-optional">(optional)</span></label>
                    <div class="wm-input-wrap">
                      <span class="wm-input-prefix"><i class="ph ph-note-pencil"></i></span>
                      <input type="text" id="withdrawNote" class="wm-input" placeholder="Reference or memo" />
                    </div>
                  </div>

                  <button type="submit" class="wm-confirm-btn wm-confirm-btn--red" id="withdrawSubmitBtn">
                    <span class="wm-btn-label"><i class="ph ph-arrow-circle-up"></i> Request Withdrawal</span>
                    <span class="wm-btn-spinner" hidden><i class="ph ph-spinner wm-spin"></i> Submitting…</span>
                  </button>
                </form>
              </div>

              <!-- Right: Summary card -->
              <div class="wm-form-right">
                <div class="wm-summary-card wm-summary-card--red" id="withdrawSummaryCard">
                  <div class="wm-summary-glow wm-sum-glow--red"></div>
                  <div class="wm-summary-blob wm-summary-blob--2"></div>
                  <div class="wm-summary-ring wm-sum-ring--red"></div>

                  <div class="wm-summary-title">
                    <i class="ph ph-receipt"></i> Withdrawal Summary
                  </div>

                  <div class="wm-summary-rows">
                    <div class="wm-summary-row">
                      <span>Requested Amount</span>
                      <strong id="sumWithdrawAmount">$0.00</strong>
                    </div>
                    <div class="wm-summary-row">
                      <span>Processing Fee (2%)</span>
                      <strong id="sumWithdrawFee" class="wm-fee-red">$0.00</strong>
                    </div>
                    <div class="wm-summary-divider"></div>
                    <div class="wm-summary-row wm-summary-total">
                      <span>You Will Receive</span>
                      <strong id="sumWithdrawNet">$0.00</strong>
                    </div>
                    <div class="wm-summary-row">
                      <span>Est. Arrival</span>
                      <strong id="sumWithdrawTime" class="wm-eta">1–3 Business Days</strong>
                    </div>
                  </div>

                  <!-- Progress bar: daily limit -->
                  <div class="wm-limit-wrap">
                    <div class="wm-limit-label">
                      <span>Daily Limit Used</span>
                      <span>$1,200 / $10,000</span>
                    </div>
                    <div class="wm-limit-track">
                      <div class="wm-limit-bar" style="width: 12%"></div>
                    </div>
                  </div>

                  <div class="wm-summary-note wm-note--warn">
                    <i class="ph ph-warning"></i>
                    Withdrawals are reviewed within 24 hours. Ensure your details are correct.
                  </div>
                </div>
              </div>

            </div>
          </div>

        </div>

      </section>

      <!-- =============================================
           SECTION 3 — TRANSACTION HISTORY
      ============================================= -->
      <section class="txn-section wt-txn-section" data-aos="fade-up">

        <!-- Wave divider at top -->
        <div class="wt-txn-wave">
          <svg viewBox="0 0 1440 60" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0,30 C480,60 960,0 1440,30 L1440,0 L0,0 Z" fill="var(--body-bg)" />
          </svg>
        </div>

        <div class="wt-txn-bg-blob"></div>
        <div class="wt-txn-bg-ring"></div>

        <div class="db-section-head">
          <h2 class="db-section-title">Transaction History</h2>
          <div class="wt-txn-filters">
            <button class="wt-filter-btn active" data-filter="all">All</button>
            <button class="wt-filter-btn" data-filter="deposit">Deposits</button>
            <button class="wt-filter-btn" data-filter="withdraw">Withdrawals</button>
          </div>
        </div>

        <div class="txn-card wt-txn-card">
          <div class="txn-card-glow"></div>
          <div class="txn-table-wrap">
            <table class="txn-table wt-txn-table" aria-label="Transaction history">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Type</th>
                  <th>Method</th>
                  <th>Amount</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody id="txnTableBody">
                <tr data-type="deposit">
                  <td><span class="txn-date">Mar 13, 2026</span></td>
                  <td><span class="txn-type txn-type--deposit"><i class="ph ph-arrow-circle-down"></i> Deposit</span></td>
                  <td><span class="txn-method"><i class="ph ph-currency-btc"></i> Bitcoin</span></td>
                  <td><span class="txn-amount txn-amount--pos">+$2,500.00</span></td>
                  <td><span class="txn-badge txn-badge--completed">Completed</span></td>
                </tr>
                <tr data-type="withdraw">
                  <td><span class="txn-date">Mar 10, 2026</span></td>
                  <td><span class="txn-type txn-type--withdraw"><i class="ph ph-arrow-circle-up"></i> Withdraw</span></td>
                  <td><span class="txn-method"><i class="ph ph-bank"></i> Bank Transfer</span></td>
                  <td><span class="txn-amount txn-amount--neg">-$1,200.00</span></td>
                  <td><span class="txn-badge txn-badge--pending">Pending</span></td>
                </tr>
                <tr data-type="deposit">
                  <td><span class="txn-date">Mar 7, 2026</span></td>
                  <td><span class="txn-type txn-type--deposit"><i class="ph ph-arrow-circle-down"></i> Deposit</span></td>
                  <td><span class="txn-method"><i class="ph ph-coins"></i> USDT TRC20</span></td>
                  <td><span class="txn-amount txn-amount--pos">+$5,000.00</span></td>
                  <td><span class="txn-badge txn-badge--completed">Completed</span></td>
                </tr>
                <tr data-type="withdraw">
                  <td><span class="txn-date">Mar 2, 2026</span></td>
                  <td><span class="txn-type txn-type--withdraw"><i class="ph ph-arrow-circle-up"></i> Withdraw</span></td>
                  <td><span class="txn-method"><i class="ph ph-paypal-logo"></i> PayPal</span></td>
                  <td><span class="txn-amount txn-amount--neg">-$800.00</span></td>
                  <td><span class="txn-badge txn-badge--rejected">Rejected</span></td>
                </tr>
                <tr data-type="deposit">
                  <td><span class="txn-date">Feb 28, 2026</span></td>
                  <td><span class="txn-type txn-type--deposit"><i class="ph ph-arrow-circle-down"></i> Deposit</span></td>
                  <td><span class="txn-method"><i class="ph ph-currency-eth"></i> Ethereum</span></td>
                  <td><span class="txn-amount txn-amount--pos">+$3,200.00</span></td>
                  <td><span class="txn-badge txn-badge--completed">Completed</span></td>
                </tr>
                <tr data-type="deposit">
                  <td><span class="txn-date">Feb 22, 2026</span></td>
                  <td><span class="txn-type txn-type--deposit"><i class="ph ph-arrow-circle-down"></i> Deposit</span></td>
                  <td><span class="txn-method"><i class="ph ph-credit-card"></i> Card</span></td>
                  <td><span class="txn-amount txn-amount--pos">+$1,000.00</span></td>
                  <td><span class="txn-badge txn-badge--completed">Completed</span></td>
                </tr>
                <tr data-type="withdraw">
                  <td><span class="txn-date">Feb 15, 2026</span></td>
                  <td><span class="txn-type txn-type--withdraw"><i class="ph ph-arrow-circle-up"></i> Withdraw</span></td>
                  <td><span class="txn-method"><i class="ph ph-currency-btc"></i> Bitcoin</span></td>
                  <td><span class="txn-amount txn-amount--neg">-$4,200.00</span></td>
                  <td><span class="txn-badge txn-badge--completed">Completed</span></td>
                </tr>
                <tr data-type="deposit">
                  <td><span class="txn-date">Feb 10, 2026</span></td>
                  <td><span class="txn-type txn-type--deposit"><i class="ph ph-arrow-circle-down"></i> Deposit</span></td>
                  <td><span class="txn-method"><i class="ph ph-bank"></i> Bank Transfer</span></td>
                  <td><span class="txn-amount txn-amount--pos">+$10,000.00</span></td>
                  <td><span class="txn-badge txn-badge--completed">Completed</span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

      </section>

    </main>
  </div>

  <!-- =============================================
       SUCCESS TOAST
  ============================================= -->
  <div class="wm-toast" id="walletToast" role="alert" aria-live="polite">
    <div class="wm-toast-icon" id="walletToastIcon"><i class="ph ph-check-circle"></i></div>
    <div class="wm-toast-body">
      <strong id="walletToastTitle">Success!</strong>
      <p id="walletToastMsg">Your request has been submitted.</p>
    </div>
    <button class="wm-toast-close" id="walletToastClose" aria-label="Close"><i class="ph ph-x"></i></button>
  </div>

  <!-- AOS -->
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script src="wallet.js"></script>
</body>
</html>
