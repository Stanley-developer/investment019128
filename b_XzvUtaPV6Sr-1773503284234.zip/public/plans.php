<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Investment Plans — Investment Company</title>

  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet" />

  <!-- Phosphor Icons -->
  <script src="https://unpkg.com/@phosphor-icons/web" defer></script>

  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

  <!-- AOS -->
  <link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css" />

  <link rel="stylesheet" href="plans.css" />
</head>
<body>

  <!-- ===================================================
       SIDEBAR — identical to wallet.html / dashboard.html
  =================================================== -->
  <aside class="sidebar" id="sidebar">
    <div class="sb-blob sb-blob--1"></div>
    <div class="sb-blob sb-blob--2"></div>
    <div class="sb-ring sb-ring--1"></div>

    <div class="sb-logo">
      <span class="logo-dot"></span>
      <span class="logo-text">LOGO</span>
      <button class="sb-collapse-btn" id="sidebarCollapseBtn" aria-label="Collapse sidebar">
        <i class="ph ph-sidebar-simple"></i>
      </button>
    </div>

    <nav class="sb-nav" aria-label="Dashboard navigation">
      <a href="dashboard.html" class="sb-link" data-section="overview">
        <span class="sb-icon"><i class="ph ph-squares-four"></i></span>
        <span class="sb-label">Dashboard</span>
      </a>
      <a href="dashboard.html#portfolio" class="sb-link" data-section="portfolio">
        <span class="sb-icon"><i class="ph ph-chart-pie-slice"></i></span>
        <span class="sb-label">Portfolio</span>
      </a>
      <a href="plans.html" class="sb-link active" data-section="plans">
        <span class="sb-icon"><i class="ph ph-trend-up"></i></span>
        <span class="sb-label">Investment Plans</span>
      </a>
      <a href="dashboard.html#transactions" class="sb-link" data-section="transactions">
        <span class="sb-icon"><i class="ph ph-arrows-left-right"></i></span>
        <span class="sb-label">Transactions</span>
      </a>
      <a href="wallet.html" class="sb-link" data-section="wallet">
        <span class="sb-icon"><i class="ph ph-wallet"></i></span>
        <span class="sb-label">Wallet</span>
      </a>
      <a href="dashboard.html#referrals" class="sb-link" data-section="referrals">
        <span class="sb-icon"><i class="ph ph-users-three"></i></span>
        <span class="sb-label">Referrals</span>
      </a>
      <a href="dashboard.html#settings" class="sb-link" data-section="settings">
        <span class="sb-icon"><i class="ph ph-gear"></i></span>
        <span class="sb-label">Settings</span>
      </a>

      <div class="sb-divider"></div>

      <a href="index.html" class="sb-link sb-logout">
        <span class="sb-icon"><i class="ph ph-sign-out"></i></span>
        <span class="sb-label">Logout</span>
      </a>
    </nav>

    <div class="sb-user">
      <div class="sb-avatar">
        <span>JD</span>
        <div class="sb-avatar-ring"></div>
      </div>
      <div class="sb-user-info">
        <span class="sb-user-name">John Doe</span>
        <span class="sb-user-role">Pro Investor</span>
      </div>
    </div>
  </aside>

  <!-- Mobile overlay -->
  <div class="sb-overlay" id="sbOverlay"></div>

  <!-- ===================================================
       MAIN WRAPPER
  =================================================== -->
  <div class="dash-wrapper" id="dashWrapper">

    <!-- ===================================================
         TOP NAVBAR — identical to wallet.html
    =================================================== -->
    <header class="dash-nav">
      <div class="dn-left">
        <button class="dn-hamburger" id="dnHamburger" aria-label="Toggle sidebar">
          <i class="ph ph-list"></i>
        </button>
        <div class="dn-search-wrap">
          <i class="ph ph-magnifying-glass"></i>
          <input type="search" placeholder="Search plans..." class="dn-search" id="dnSearch" aria-label="Search" />
        </div>
      </div>

      <div class="dn-right">
        <div class="dn-action-btn" id="notifBtn" aria-label="Notifications" role="button" tabindex="0">
          <i class="ph ph-bell"></i>
          <span class="dn-badge">3</span>
          <div class="dn-dropdown notif-dropdown" id="notifDropdown">
            <div class="dd-header">
              <span>Notifications</span>
              <button class="dd-mark-read">Mark all read</button>
            </div>
            <div class="dd-list">
              <div class="dd-item dd-item--unread">
                <div class="dd-item-icon dd-icon-success"><i class="ph ph-check-circle"></i></div>
                <div class="dd-item-body"><p>Deposit of $2,500 confirmed</p><span>2 min ago</span></div>
              </div>
              <div class="dd-item dd-item--unread">
                <div class="dd-item-icon dd-icon-info"><i class="ph ph-trend-up"></i></div>
                <div class="dd-item-body"><p>Growth Plan profit credited</p><span>1 hr ago</span></div>
              </div>
              <div class="dd-item dd-item--unread">
                <div class="dd-item-icon dd-icon-warn"><i class="ph ph-warning"></i></div>
                <div class="dd-item-body"><p>Verify identity to unlock withdrawals</p><span>Yesterday</span></div>
              </div>
            </div>
          </div>
        </div>

        <div class="dn-action-btn" id="msgBtn" aria-label="Messages" role="button" tabindex="0">
          <i class="ph ph-chat-circle-dots"></i>
          <span class="dn-badge dn-badge--teal">2</span>
        </div>

        <button class="dn-theme-btn" id="themeToggle" aria-label="Toggle theme">
          <i class="ph ph-moon theme-icon-ph"></i>
        </button>

        <div class="dn-profile-wrap" id="profileWrap">
          <button class="dn-profile-btn" id="profileBtn" aria-label="Profile menu" aria-haspopup="true" aria-expanded="false">
            <div class="dn-avatar">JD</div>
            <span class="dn-profile-name">John Doe</span>
            <i class="ph ph-caret-down"></i>
          </button>
          <div class="dn-dropdown profile-dropdown" id="profileDropdown">
            <a href="#" class="dd-profile-item"><i class="ph ph-user"></i> Profile</a>
            <a href="#" class="dd-profile-item"><i class="ph ph-gear"></i> Settings</a>
            <div class="dd-divider"></div>
            <a href="index.html" class="dd-profile-item dd-logout"><i class="ph ph-sign-out"></i> Logout</a>
          </div>
        </div>
      </div>
    </header>

    <!-- ===================================================
         MAIN CONTENT
    =================================================== -->
    <main class="dash-content">

      <!-- =============================================
           SECTION 1 — PAGE BANNER
      ============================================= -->
      <section class="plans-banner">
        <!-- Background shapes -->
        <div class="pb-blob pb-blob--1"></div>
        <div class="pb-blob pb-blob--2"></div>
        <div class="pb-blob pb-blob--3"></div>
        <div class="pb-ring pb-ring--1"></div>
        <div class="pb-ring pb-ring--2"></div>
        <div class="pb-glow"></div>

        <!-- SVG wave at bottom -->
        <div class="pb-wave">
          <svg viewBox="0 0 1440 80" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0,20 C480,80 960,0 1440,50 L1440,80 L0,80 Z" fill="var(--body-bg)" />
          </svg>
        </div>

        <div class="pb-inner">
          <div class="pb-title-block">
            <div class="pb-page-tag"><i class="ph ph-trend-up"></i> Investment Plans</div>
            <h1 class="pb-title">Grow Your <span class="pb-accent">Wealth</span></h1>
            <p class="pb-subtitle">Choose a plan, stake your funds, and earn daily rewards for 100 days. All plans return 3x your stake.</p>
          </div>

          <!-- Investment summary stat cards in banner -->
          <div class="pb-stat-cards">
            <div class="pbs-card" data-aos="fade-up" data-aos-delay="0">
              <div class="pbs-icon-wrap pbs-color--teal"><i class="ph ph-coins"></i></div>
              <div class="pbs-body">
                <span class="pbs-label">Total Invested</span>
                <div class="pbs-value" data-target="24500" data-prefix="$">$0</div>
              </div>
              <div class="pbs-arc"></div>
            </div>
            <div class="pbs-card" data-aos="fade-up" data-aos-delay="80">
              <div class="pbs-icon-wrap pbs-color--sky"><i class="ph ph-chart-line-up"></i></div>
              <div class="pbs-body">
                <span class="pbs-label">Total Earnings</span>
                <div class="pbs-value" data-target="8340" data-prefix="$">$0</div>
              </div>
              <div class="pbs-arc"></div>
            </div>
            <div class="pbs-card" data-aos="fade-up" data-aos-delay="160">
              <div class="pbs-icon-wrap pbs-color--gold"><i class="ph ph-lightning"></i></div>
              <div class="pbs-body">
                <span class="pbs-label">Active Plans</span>
                <div class="pbs-value" data-target="3" data-prefix="">0</div>
              </div>
              <div class="pbs-arc"></div>
            </div>
            <div class="pbs-card" data-aos="fade-up" data-aos-delay="240">
              <div class="pbs-icon-wrap pbs-color--green"><i class="ph ph-sun"></i></div>
              <div class="pbs-body">
                <span class="pbs-label">Daily Earnings</span>
                <div class="pbs-value" data-target="367" data-prefix="$">$0</div>
              </div>
              <div class="pbs-arc"></div>
            </div>
          </div>
        </div>
      </section>

      <!-- =============================================
           SECTION 2 — INVESTMENT PLAN CARDS
      ============================================= -->
      <section class="pl-section plans-grid-section">

        <!-- Floating shapes behind section -->
        <div class="pgs-blob pgs-blob--1"></div>
        <div class="pgs-blob pgs-blob--2"></div>
        <div class="pgs-ring pgs-ring--1"></div>

        <div class="pl-section-head" data-aos="fade-up">
          <h2 class="pl-section-title">Choose Your <span class="pl-accent">Plan</span></h2>
          <p class="pl-section-sub">All plans run for 100 days and return 300% of your initial stake.</p>
        </div>

        <div class="plan-cards-grid">

          <!-- Starter Plan -->
          <div class="plan-card plan-card--starter" data-aos="fade-up" data-aos-delay="0">
            <div class="pc-grad-border"></div>
            <div class="pc-glow pc-glow--starter"></div>
            <div class="pc-blob pc-blob--1"></div>
            <div class="pc-ring pc-ring--1"></div>
            <div class="pc-inner">
              <div class="pc-badge pc-badge--starter">Starter</div>
              <div class="pc-icon-wrap pc-icon--starter">
                <i class="ph ph-plant"></i>
              </div>
              <h3 class="pc-name">Starter Plan</h3>
              <p class="pc-tagline">Perfect for new investors beginning their wealth journey.</p>
              <div class="pc-divider"></div>
              <div class="pc-stats">
                <div class="pc-stat">
                  <span class="pc-stat-label">Min Investment</span>
                  <strong class="pc-stat-val">$100</strong>
                </div>
                <div class="pc-stat">
                  <span class="pc-stat-label">Max Investment</span>
                  <strong class="pc-stat-val">$499</strong>
                </div>
                <div class="pc-stat pc-stat--highlight">
                  <span class="pc-stat-label">Daily Reward</span>
                  <strong class="pc-stat-val pc-val--teal">1%</strong>
                </div>
                <div class="pc-stat">
                  <span class="pc-stat-label">Duration</span>
                  <strong class="pc-stat-val">100 Days</strong>
                </div>
                <div class="pc-stat">
                  <span class="pc-stat-label">Total Return</span>
                  <strong class="pc-stat-val pc-val--gold">300%</strong>
                </div>
              </div>
              <button class="pc-invest-btn pc-btn--starter" data-plan="Starter" data-min="100" data-max="499" data-daily="1">
                <i class="ph ph-arrow-circle-right"></i> Invest Now
              </button>
            </div>
          </div>

          <!-- Growth Plan -->
          <div class="plan-card plan-card--growth plan-card--featured" data-aos="fade-up" data-aos-delay="120">
            <div class="pc-featured-tag">Most Popular</div>
            <div class="pc-grad-border pc-grad-border--growth"></div>
            <div class="pc-glow pc-glow--growth"></div>
            <div class="pc-blob pc-blob--2"></div>
            <div class="pc-ring pc-ring--2"></div>
            <div class="pc-inner">
              <div class="pc-badge pc-badge--growth">Growth</div>
              <div class="pc-icon-wrap pc-icon--growth">
                <i class="ph ph-chart-line-up"></i>
              </div>
              <h3 class="pc-name">Growth Plan</h3>
              <p class="pc-tagline">Accelerate your returns with our mid-tier investment strategy.</p>
              <div class="pc-divider"></div>
              <div class="pc-stats">
                <div class="pc-stat">
                  <span class="pc-stat-label">Min Investment</span>
                  <strong class="pc-stat-val">$500</strong>
                </div>
                <div class="pc-stat">
                  <span class="pc-stat-label">Max Investment</span>
                  <strong class="pc-stat-val">$999</strong>
                </div>
                <div class="pc-stat pc-stat--highlight">
                  <span class="pc-stat-label">Daily Reward</span>
                  <strong class="pc-stat-val pc-val--teal">1.5%</strong>
                </div>
                <div class="pc-stat">
                  <span class="pc-stat-label">Duration</span>
                  <strong class="pc-stat-val">100 Days</strong>
                </div>
                <div class="pc-stat">
                  <span class="pc-stat-label">Total Return</span>
                  <strong class="pc-stat-val pc-val--gold">300%</strong>
                </div>
              </div>
              <button class="pc-invest-btn pc-btn--growth" data-plan="Growth" data-min="500" data-max="999" data-daily="1.5">
                <i class="ph ph-arrow-circle-right"></i> Invest Now
              </button>
            </div>
          </div>

          <!-- Premium Plan -->
          <div class="plan-card plan-card--premium" data-aos="fade-up" data-aos-delay="240">
            <div class="pc-grad-border pc-grad-border--premium"></div>
            <div class="pc-glow pc-glow--premium"></div>
            <div class="pc-blob pc-blob--3"></div>
            <div class="pc-ring pc-ring--3"></div>
            <div class="pc-inner">
              <div class="pc-badge pc-badge--premium">Premium</div>
              <div class="pc-icon-wrap pc-icon--premium">
                <i class="ph ph-crown"></i>
              </div>
              <h3 class="pc-name">Premium Plan</h3>
              <p class="pc-tagline">Maximum rewards for serious high-value investors.</p>
              <div class="pc-divider"></div>
              <div class="pc-stats">
                <div class="pc-stat">
                  <span class="pc-stat-label">Min Investment</span>
                  <strong class="pc-stat-val">$1,000</strong>
                </div>
                <div class="pc-stat">
                  <span class="pc-stat-label">Max Investment</span>
                  <strong class="pc-stat-val">Unlimited</strong>
                </div>
                <div class="pc-stat pc-stat--highlight">
                  <span class="pc-stat-label">Daily Reward</span>
                  <strong class="pc-stat-val pc-val--teal">2%</strong>
                </div>
                <div class="pc-stat">
                  <span class="pc-stat-label">Duration</span>
                  <strong class="pc-stat-val">100 Days</strong>
                </div>
                <div class="pc-stat">
                  <span class="pc-stat-label">Total Return</span>
                  <strong class="pc-stat-val pc-val--gold">300%</strong>
                </div>
              </div>
              <button class="pc-invest-btn pc-btn--premium" data-plan="Premium" data-min="1000" data-max="999999" data-daily="2">
                <i class="ph ph-arrow-circle-right"></i> Invest Now
              </button>
            </div>
          </div>

        </div>
      </section>

      <!-- =============================================
           SECTION 3 — PROFIT SIMULATOR
      ============================================= -->
      <section class="pl-section simulator-section" data-aos="fade-up">

        <!-- Diagonal shape background -->
        <div class="sim-diag sim-diag--top">
          <svg viewBox="0 0 1440 60" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0,60 L1440,0 L1440,60 Z" fill="var(--sim-bg)" />
          </svg>
        </div>
        <div class="sim-blob sim-blob--1"></div>
        <div class="sim-blob sim-blob--2"></div>
        <div class="sim-ring sim-ring--1"></div>
        <div class="sim-glow"></div>

        <div class="sim-inner">
          <div class="sim-text-col">
            <div class="pl-page-tag"><i class="ph ph-calculator"></i> Simulator</div>
            <h2 class="pl-section-title">Profit <span class="pl-accent">Calculator</span></h2>
            <p class="pl-section-sub">Enter your investment amount and see your projected returns in real time.</p>

            <div class="sim-form">
              <div class="sim-field">
                <label for="simPlan" class="sim-label">Select Plan</label>
                <div class="sim-select-wrap">
                  <i class="ph ph-trend-up"></i>
                  <select id="simPlan" class="sim-select" aria-label="Select investment plan">
                    <option value="1">Starter — 1% daily</option>
                    <option value="1.5" selected>Growth — 1.5% daily</option>
                    <option value="2">Premium — 2% daily</option>
                  </select>
                </div>
              </div>
              <div class="sim-field">
                <label for="simAmount" class="sim-label">Investment Amount ($)</label>
                <div class="sim-input-wrap">
                  <i class="ph ph-currency-dollar"></i>
                  <input type="number" id="simAmount" class="sim-input" placeholder="e.g. 1000" min="100" aria-label="Investment amount" />
                </div>
              </div>
            </div>
          </div>

          <div class="sim-results-col">
            <div class="sim-result-card">
              <div class="sim-rc-glow"></div>
              <div class="sim-rc-ring"></div>
              <h3 class="sim-rc-title">Projected Returns</h3>
              <div class="sim-rc-grid">
                <div class="sim-rc-item">
                  <span class="sim-rc-label"><i class="ph ph-sun"></i> Daily Reward</span>
                  <div class="sim-rc-val" id="simDaily">$0.00</div>
                </div>
                <div class="sim-rc-item">
                  <span class="sim-rc-label"><i class="ph ph-calendar-check"></i> Total After 100 Days</span>
                  <div class="sim-rc-val sim-rc-val--big" id="simTotal">$0.00</div>
                </div>
                <div class="sim-rc-item">
                  <span class="sim-rc-label"><i class="ph ph-arrow-up-right"></i> Net Profit</span>
                  <div class="sim-rc-val sim-rc-val--profit" id="simProfit">$0.00</div>
                </div>
                <div class="sim-rc-item">
                  <span class="sim-rc-label"><i class="ph ph-percent"></i> ROI</span>
                  <div class="sim-rc-val sim-rc-val--roi" id="simROI">0%</div>
                </div>
              </div>
              <div class="sim-rc-bar-wrap">
                <span class="sim-rc-bar-label">Return Progress</span>
                <div class="sim-rc-bar-track">
                  <div class="sim-rc-bar-fill" id="simBarFill" style="width:0%"></div>
                </div>
                <span class="sim-rc-bar-pct" id="simBarPct">0%</span>
              </div>
            </div>
          </div>
        </div>

        <div class="sim-diag sim-diag--bottom">
          <svg viewBox="0 0 1440 60" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0,0 L1440,60 L0,60 Z" fill="var(--sim-bg)" />
          </svg>
        </div>
      </section>

      <!-- =============================================
           SECTION 4 — ACTIVE INVESTMENTS
      ============================================= -->
      <section class="pl-section active-inv-section" data-aos="fade-up">

        <div class="ai-arc ai-arc--1"></div>
        <div class="ai-blob ai-blob--1"></div>

        <div class="pl-section-head">
          <h2 class="pl-section-title">My Active <span class="pl-accent">Investments</span></h2>
          <p class="pl-section-sub">Track the progress of your current staking positions.</p>
        </div>

        <div class="ai-cards-grid">

          <div class="ai-card" data-aos="fade-up" data-aos-delay="0">
            <div class="ai-card-glow"></div>
            <div class="ai-card-top-shape"></div>
            <div class="ai-card-header">
              <div class="ai-plan-badge ai-badge--starter">Starter</div>
              <span class="ai-status ai-status--active"><i class="ph ph-circle-fill"></i> Active</span>
            </div>
            <div class="ai-card-body">
              <div class="ai-amounts">
                <div class="ai-amount-item">
                  <span>Invested</span>
                  <strong>$250.00</strong>
                </div>
                <div class="ai-amount-item">
                  <span>Start Date</span>
                  <strong>Feb 2, 2026</strong>
                </div>
                <div class="ai-amount-item">
                  <span>Days Left</span>
                  <strong>61 days</strong>
                </div>
                <div class="ai-amount-item">
                  <span>Earned So Far</span>
                  <strong class="ai-earned">+$97.50</strong>
                </div>
              </div>
              <div class="ai-progress-wrap">
                <div class="ai-progress-labels">
                  <span>Day 39 of 100</span>
                  <span class="ai-pct">39%</span>
                </div>
                <div class="ai-progress-track">
                  <div class="ai-progress-bar" data-pct="39" style="width:0%"></div>
                </div>
              </div>
            </div>
          </div>

          <div class="ai-card" data-aos="fade-up" data-aos-delay="100">
            <div class="ai-card-glow ai-card-glow--teal"></div>
            <div class="ai-card-top-shape ai-top-shape--teal"></div>
            <div class="ai-card-header">
              <div class="ai-plan-badge ai-badge--growth">Growth</div>
              <span class="ai-status ai-status--active"><i class="ph ph-circle-fill"></i> Active</span>
            </div>
            <div class="ai-card-body">
              <div class="ai-amounts">
                <div class="ai-amount-item">
                  <span>Invested</span>
                  <strong>$750.00</strong>
                </div>
                <div class="ai-amount-item">
                  <span>Start Date</span>
                  <strong>Jan 15, 2026</strong>
                </div>
                <div class="ai-amount-item">
                  <span>Days Left</span>
                  <strong>43 days</strong>
                </div>
                <div class="ai-amount-item">
                  <span>Earned So Far</span>
                  <strong class="ai-earned ai-earned--teal">+$855.00</strong>
                </div>
              </div>
              <div class="ai-progress-wrap">
                <div class="ai-progress-labels">
                  <span>Day 57 of 100</span>
                  <span class="ai-pct">57%</span>
                </div>
                <div class="ai-progress-track">
                  <div class="ai-progress-bar ai-bar--teal" data-pct="57" style="width:0%"></div>
                </div>
              </div>
            </div>
          </div>

          <div class="ai-card" data-aos="fade-up" data-aos-delay="200">
            <div class="ai-card-glow ai-card-glow--gold"></div>
            <div class="ai-card-top-shape ai-top-shape--gold"></div>
            <div class="ai-card-header">
              <div class="ai-plan-badge ai-badge--premium">Premium</div>
              <span class="ai-status ai-status--maturing"><i class="ph ph-circle-fill"></i> Maturing</span>
            </div>
            <div class="ai-card-body">
              <div class="ai-amounts">
                <div class="ai-amount-item">
                  <span>Invested</span>
                  <strong>$2,000.00</strong>
                </div>
                <div class="ai-amount-item">
                  <span>Start Date</span>
                  <strong>Dec 4, 2025</strong>
                </div>
                <div class="ai-amount-item">
                  <span>Days Left</span>
                  <strong>6 days</strong>
                </div>
                <div class="ai-amount-item">
                  <span>Earned So Far</span>
                  <strong class="ai-earned ai-earned--gold">+$3,760.00</strong>
                </div>
              </div>
              <div class="ai-progress-wrap">
                <div class="ai-progress-labels">
                  <span>Day 94 of 100</span>
                  <span class="ai-pct">94%</span>
                </div>
                <div class="ai-progress-track">
                  <div class="ai-progress-bar ai-bar--gold" data-pct="94" style="width:0%"></div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </section>

      <!-- =============================================
           SECTION 5 — DAILY CLAIM PANEL
      ============================================= -->
      <section class="pl-section claim-section" data-aos="fade-up">

        <div class="claim-wave claim-wave--top">
          <svg viewBox="0 0 1440 60" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0,30 C360,60 1080,0 1440,40 L1440,0 L0,0 Z" fill="var(--body-bg)" />
          </svg>
        </div>
        <div class="claim-blob claim-blob--1"></div>
        <div class="claim-blob claim-blob--2"></div>
        <div class="claim-ring claim-ring--1"></div>
        <div class="claim-glow"></div>

        <div class="claim-inner">
          <div class="claim-text-block">
            <div class="pl-page-tag pl-tag--gold"><i class="ph ph-sun"></i> Daily Rewards</div>
            <h2 class="pl-section-title">Daily <span class="pl-accent">Claim</span></h2>
            <p class="pl-section-sub">Claim your combined daily rewards from all active plans. Resets every 24 hours.</p>
          </div>

          <div class="claim-panel">
            <div class="cp-glow"></div>
            <div class="cp-ring"></div>

            <div class="cp-reward-display">
              <span class="cp-reward-label">Today's Reward</span>
              <div class="cp-reward-amount">$<span id="claimAmount">367.50</span></div>
              <div class="cp-reward-breakdown">
                <span><i class="ph ph-plant"></i> Starter: $2.50</span>
                <span><i class="ph ph-chart-line-up"></i> Growth: $11.25</span>
                <span><i class="ph ph-crown"></i> Premium: $40.00</span>
              </div>
            </div>

            <div class="cp-status-ring" id="cpStatusRing">
              <div class="cp-status-pulse"></div>
              <i class="ph ph-coins cp-status-icon" id="cpStatusIcon"></i>
            </div>

            <div class="cp-actions">
              <button class="cp-claim-btn" id="claimBtn">
                <i class="ph ph-hand-coins"></i>
                <span>Claim Reward</span>
              </button>
              <div class="cp-countdown" id="cpCountdown" style="display:none">
                <i class="ph ph-clock"></i>
                <span>Next claim in: <strong id="countdownTimer">23:59:59</strong></span>
              </div>
            </div>

            <div class="cp-history">
              <span class="cp-history-label">Last claimed:</span>
              <span class="cp-history-val" id="cpLastClaim">Not yet claimed today</span>
            </div>
          </div>
        </div>

        <div class="claim-wave claim-wave--bottom">
          <svg viewBox="0 0 1440 60" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0,30 C360,0 1080,60 1440,20 L1440,60 L0,60 Z" fill="var(--body-bg)" />
          </svg>
        </div>
      </section>

      <!-- =============================================
           SECTION 6 — REFERRAL EARNINGS
      ============================================= -->
      <section class="pl-section referral-section" data-aos="fade-up">

        <div class="ref-blob ref-blob--1"></div>
        <div class="ref-blob ref-blob--2"></div>
        <div class="ref-ring ref-ring--1"></div>

        <div class="pl-section-head">
          <h2 class="pl-section-title">Referral <span class="pl-accent">Earnings</span></h2>
          <p class="pl-section-sub">Earn bonus commissions from every person you refer and their downline activity.</p>
        </div>

        <div class="ref-grid">

          <!-- Referral stat cards -->
          <div class="ref-stats-col">
            <div class="ref-stat-card ref-stat--teal" data-aos="fade-right">
              <div class="ref-sc-shape"></div>
              <div class="ref-sc-icon"><i class="ph ph-coins"></i></div>
              <div class="ref-sc-body">
                <span>Total Referral Earnings</span>
                <strong data-target="1240" data-prefix="$">$0</strong>
              </div>
            </div>
            <div class="ref-stat-card ref-stat--sky" data-aos="fade-right" data-aos-delay="80">
              <div class="ref-sc-shape"></div>
              <div class="ref-sc-icon"><i class="ph ph-users-three"></i></div>
              <div class="ref-sc-body">
                <span>Active Referrals</span>
                <strong data-target="14" data-prefix="">0</strong>
              </div>
            </div>
            <div class="ref-stat-card ref-stat--gold" data-aos="fade-right" data-aos-delay="160">
              <div class="ref-sc-shape"></div>
              <div class="ref-sc-icon"><i class="ph ph-arrow-bend-down-right"></i></div>
              <div class="ref-sc-body">
                <span>Downline Stake Earnings</span>
                <strong data-target="480" data-prefix="$">$0</strong>
              </div>
            </div>
          </div>

          <!-- Referral bonus table -->
          <div class="ref-table-col" data-aos="fade-left">
            <div class="ref-table-card">
              <div class="ref-tc-glow"></div>
              <div class="ref-tc-arc"></div>
              <h3 class="ref-tc-title"><i class="ph ph-tree-structure"></i> Referral Bonus Structure</h3>
              <div class="ref-bonus-table">
                <div class="rbt-row rbt-header">
                  <span>Level</span>
                  <span>Bonus Rate</span>
                  <span>Your Earnings</span>
                </div>
                <div class="rbt-row rbt-row--1">
                  <span><i class="ph ph-user"></i> Level 1 (Direct)</span>
                  <span class="rbt-rate">5%</span>
                  <span class="rbt-earn" data-target="840" data-prefix="$">$0</span>
                </div>
                <div class="rbt-row rbt-row--2">
                  <span><i class="ph ph-users"></i> Level 2</span>
                  <span class="rbt-rate">3%</span>
                  <span class="rbt-earn" data-target="280" data-prefix="$">$0</span>
                </div>
                <div class="rbt-row rbt-row--3">
                  <span><i class="ph ph-users-three"></i> Level 3</span>
                  <span class="rbt-rate">2%</span>
                  <span class="rbt-earn" data-target="120" data-prefix="$">$0</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- =============================================
           SECTION 7 — DOWNLINE ACTIVITY
      ============================================= -->
      <section class="pl-section downline-section" data-aos="fade-up">

        <div class="dl-wave dl-wave--top">
          <svg viewBox="0 0 1440 50" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0,25 C480,50 960,0 1440,30 L1440,0 L0,0 Z" fill="var(--body-bg)" />
          </svg>
        </div>
        <div class="dl-blob dl-blob--1"></div>
        <div class="dl-ring dl-ring--1"></div>

        <div class="pl-section-head">
          <h2 class="pl-section-title">Downline <span class="pl-accent">Activity</span></h2>
          <p class="pl-section-sub">Recent investments made by your referral network.</p>
        </div>

        <div class="dl-table-card">
          <div class="dl-tc-glow"></div>
          <div class="dl-table-wrap">
            <table class="dl-table" aria-label="Downline activity">
              <thead>
                <tr>
                  <th>Referral</th>
                  <th>Plan Joined</th>
                  <th>Amount</th>
                  <th>Your Bonus</th>
                  <th>Level</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><div class="dl-user"><div class="dl-avatar dl-av--teal">AJ</div><span>Alex Johnson</span></div></td>
                  <td><span class="dl-plan-badge dl-plan--growth">Growth</span></td>
                  <td><strong>$750.00</strong></td>
                  <td><span class="dl-bonus dl-bonus--pos">+$37.50</span></td>
                  <td><span class="dl-level dl-level--1">L1</span></td>
                </tr>
                <tr>
                  <td><div class="dl-user"><div class="dl-avatar dl-av--sky">SM</div><span>Sarah Miller</span></div></td>
                  <td><span class="dl-plan-badge dl-plan--premium">Premium</span></td>
                  <td><strong>$2,500.00</strong></td>
                  <td><span class="dl-bonus dl-bonus--pos">+$125.00</span></td>
                  <td><span class="dl-level dl-level--1">L1</span></td>
                </tr>
                <tr>
                  <td><div class="dl-user"><div class="dl-avatar dl-av--gold">RC</div><span>Ryan Chen</span></div></td>
                  <td><span class="dl-plan-badge dl-plan--starter">Starter</span></td>
                  <td><strong>$200.00</strong></td>
                  <td><span class="dl-bonus dl-bonus--pos">+$6.00</span></td>
                  <td><span class="dl-level dl-level--2">L2</span></td>
                </tr>
                <tr>
                  <td><div class="dl-user"><div class="dl-avatar dl-av--purple">LP</div><span>Lisa Park</span></div></td>
                  <td><span class="dl-plan-badge dl-plan--growth">Growth</span></td>
                  <td><strong>$500.00</strong></td>
                  <td><span class="dl-bonus dl-bonus--pos">+$10.00</span></td>
                  <td><span class="dl-level dl-level--3">L3</span></td>
                </tr>
                <tr>
                  <td><div class="dl-user"><div class="dl-avatar dl-av--teal">MK</div><span>Mike Kumar</span></div></td>
                  <td><span class="dl-plan-badge dl-plan--premium">Premium</span></td>
                  <td><strong>$5,000.00</strong></td>
                  <td><span class="dl-bonus dl-bonus--pos">+$250.00</span></td>
                  <td><span class="dl-level dl-level--1">L1</span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div class="dl-wave dl-wave--bottom">
          <svg viewBox="0 0 1440 50" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0,20 C480,0 960,50 1440,25 L1440,50 L0,50 Z" fill="var(--body-bg)" />
          </svg>
        </div>
      </section>

      <!-- =============================================
           SECTION 8 — EARNINGS CHART
      ============================================= -->
      <section class="pl-section earnings-chart-section" data-aos="fade-up">

        <div class="ec-blob ec-blob--1"></div>
        <div class="ec-ring ec-ring--1"></div>

        <div class="ec-card">
          <div class="ec-card-glow"></div>
          <div class="ec-card-arc"></div>
          <div class="ec-card-header">
            <div>
              <h2 class="pl-section-title">Earnings <span class="pl-accent">Growth</span></h2>
              <p class="pl-section-sub">Daily and cumulative profit over your active investment period.</p>
            </div>
            <div class="ec-tabs">
              <button class="ec-tab active" data-chart="daily">Daily</button>
              <button class="ec-tab" data-chart="cumulative">Cumulative</button>
            </div>
          </div>
          <div class="ec-chart-wrap">
            <canvas id="earningsChart" aria-label="Earnings growth chart"></canvas>
          </div>
        </div>
      </section>

      <!-- =============================================
           SECTION 9 — HOW IT WORKS
      ============================================= -->
      <section class="pl-section how-section" data-aos="fade-up">

        <div class="how-wave how-wave--top">
          <svg viewBox="0 0 1440 70" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0,35 C480,70 960,0 1440,45 L1440,0 L0,0 Z" fill="var(--body-bg)" />
          </svg>
        </div>
        <div class="how-blob how-blob--1"></div>
        <div class="how-blob how-blob--2"></div>
        <div class="how-ring how-ring--1"></div>
        <div class="how-glow"></div>

        <div class="pl-section-head">
          <h2 class="pl-section-title">How It <span class="pl-accent">Works</span></h2>
          <p class="pl-section-sub">Four simple steps to start growing your wealth today.</p>
        </div>

        <div class="how-steps">

          <div class="how-step" data-aos="fade-up" data-aos-delay="0">
            <div class="hs-connector"></div>
            <div class="hs-node">
              <div class="hs-node-ring hs-ring--teal"></div>
              <div class="hs-icon-wrap hs-icon--teal"><i class="ph ph-list-magnifying-glass"></i></div>
              <span class="hs-step-num">01</span>
            </div>
            <div class="hs-content">
              <h3>Choose a Plan</h3>
              <p>Browse our Starter, Growth, or Premium plans and select the one that matches your investment goals.</p>
            </div>
          </div>

          <div class="how-step" data-aos="fade-up" data-aos-delay="100">
            <div class="hs-connector"></div>
            <div class="hs-node">
              <div class="hs-node-ring hs-ring--sky"></div>
              <div class="hs-icon-wrap hs-icon--sky"><i class="ph ph-coins"></i></div>
              <span class="hs-step-num">02</span>
            </div>
            <div class="hs-content">
              <h3>Stake Your Funds</h3>
              <p>Deposit your chosen amount securely. Your funds are staked immediately and start earning rewards.</p>
            </div>
          </div>

          <div class="how-step" data-aos="fade-up" data-aos-delay="200">
            <div class="hs-connector"></div>
            <div class="hs-node">
              <div class="hs-node-ring hs-ring--gold"></div>
              <div class="hs-icon-wrap hs-icon--gold"><i class="ph ph-sun"></i></div>
              <span class="hs-step-num">03</span>
            </div>
            <div class="hs-content">
              <h3>Earn Daily Rewards</h3>
              <p>Receive daily percentage returns for 100 days straight. Claim your rewards each day with one click.</p>
            </div>
          </div>

          <div class="how-step how-step--last" data-aos="fade-up" data-aos-delay="300">
            <div class="hs-node">
              <div class="hs-node-ring hs-ring--green"></div>
              <div class="hs-icon-wrap hs-icon--green"><i class="ph ph-arrow-up-right"></i></div>
              <span class="hs-step-num">04</span>
            </div>
            <div class="hs-content">
              <h3>Withdraw Profits</h3>
              <p>Once earned, transfer your profits directly to your wallet. Fast, secure, and hassle-free withdrawals.</p>
            </div>
          </div>

        </div>

        <div class="how-wave how-wave--bottom">
          <svg viewBox="0 0 1440 70" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0,35 C480,0 960,70 1440,30 L1440,70 L0,70 Z" fill="var(--body-bg)" />
          </svg>
        </div>
      </section>

    </main>
  </div>

  <!-- =============================================
       INVESTMENT CONFIRMATION MODAL
  ============================================= -->
  <div class="modal-overlay" id="investModal" aria-modal="true" role="dialog" aria-labelledby="modalTitle">
    <div class="modal-card">
      <div class="modal-glow"></div>
      <div class="modal-blob modal-blob--1"></div>
      <div class="modal-ring modal-ring--1"></div>

      <div class="modal-header">
        <div class="modal-badge" id="modalBadge">Growth</div>
        <button class="modal-close" id="modalClose" aria-label="Close modal"><i class="ph ph-x"></i></button>
      </div>

      <div class="modal-body">
        <div class="modal-icon-wrap" id="modalIconWrap">
          <i class="ph ph-chart-line-up"></i>
        </div>
        <h2 class="modal-title" id="modalTitle">Invest in Growth Plan</h2>
        <p class="modal-sub" id="modalSub">Daily reward: 1.5% for 100 days — Total return: 300%</p>

        <div class="modal-form">
          <div class="modal-field">
            <label for="modalAmount" class="modal-label">Investment Amount ($)</label>
            <div class="modal-input-wrap">
              <i class="ph ph-currency-dollar"></i>
              <input type="number" id="modalAmount" class="modal-input" placeholder="Enter amount" aria-label="Investment amount" />
            </div>
            <span class="modal-field-hint" id="modalAmountHint">Min: $500 — Max: $999</span>
          </div>

          <div class="modal-projection">
            <div class="mp-item">
              <span>Daily Reward</span>
              <strong id="mpDaily">$0.00</strong>
            </div>
            <div class="mp-item">
              <span>After 100 Days</span>
              <strong id="mpTotal">$0.00</strong>
            </div>
            <div class="mp-item mp-item--highlight">
              <span>Net Profit</span>
              <strong id="mpProfit">$0.00</strong>
            </div>
          </div>
        </div>
      </div>

      <div class="modal-footer">
        <button class="modal-cancel-btn" id="modalCancel">Cancel</button>
        <button class="modal-invest-btn" id="modalInvestBtn">
          <span class="modal-btn-text"><i class="ph ph-arrow-circle-right"></i> Confirm Investment</span>
          <span class="modal-btn-spinner" style="display:none"><i class="ph ph-spinner"></i></span>
        </button>
      </div>
    </div>
  </div>

  <!-- Toast notification -->
  <div class="plans-toast" id="plansToast" role="alert" aria-live="polite">
    <div class="pt-icon" id="ptIcon"><i class="ph ph-check-circle"></i></div>
    <div class="pt-body">
      <strong id="ptTitle">Investment Confirmed!</strong>
      <span id="ptMsg">Your Growth Plan is now active.</span>
    </div>
    <button class="pt-close" id="ptClose" aria-label="Close notification"><i class="ph ph-x"></i></button>
  </div>

  <!-- AOS -->
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script src="plans.js"></script>
</body>
</html>
