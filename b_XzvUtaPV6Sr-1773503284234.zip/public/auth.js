// ===========================
//  DARK / LIGHT MODE — shared localStorage key with index.html
// ===========================
const html        = document.documentElement;
const themeToggle = document.getElementById('themeToggle');

function setTheme(theme) {
  html.setAttribute('data-theme', theme);
  localStorage.setItem('theme', theme);
  const icon = themeToggle.querySelector('.theme-icon-ph');
  if (icon) {
    icon.className = theme === 'dark'
      ? 'ph ph-sun theme-icon-ph'
      : 'ph ph-moon theme-icon-ph';
  }
}

// Load saved theme on page init — same key as index.html so they sync
(function () {
  const saved = localStorage.getItem('theme') || 'light';
  setTheme(saved);
})();

themeToggle.addEventListener('click', () => {
  const current = html.getAttribute('data-theme');
  setTheme(current === 'dark' ? 'light' : 'dark');
});

// ===========================
//  TAB SWITCHER
// ===========================
const tabLogin    = document.getElementById('tabLogin');
const tabRegister = document.getElementById('tabRegister');
const panelLogin  = document.getElementById('panelLogin');
const panelRegister = document.getElementById('panelRegister');
const indicator   = document.getElementById('tabIndicator');

function switchTab(target) {
  if (target === 'login') {
    tabLogin.classList.add('active');
    tabLogin.setAttribute('aria-selected', 'true');
    tabRegister.classList.remove('active');
    tabRegister.setAttribute('aria-selected', 'false');
    indicator.classList.remove('right');
    panelLogin.classList.add('active');
    panelRegister.classList.remove('active');
  } else {
    tabRegister.classList.add('active');
    tabRegister.setAttribute('aria-selected', 'true');
    tabLogin.classList.remove('active');
    tabLogin.setAttribute('aria-selected', 'false');
    indicator.classList.add('right');
    panelRegister.classList.add('active');
    panelLogin.classList.remove('active');
  }
}

tabLogin.addEventListener('click',    () => switchTab('login'));
tabRegister.addEventListener('click', () => switchTab('register'));

// Switch links inside forms
document.querySelectorAll('.switch-link').forEach(btn => {
  btn.addEventListener('click', () => switchTab(btn.getAttribute('data-target')));
});

// ===========================
//  PASSWORD SHOW / HIDE
// ===========================
document.querySelectorAll('.pw-toggle').forEach(btn => {
  btn.addEventListener('click', () => {
    const targetId = btn.getAttribute('data-target');
    const input    = document.getElementById(targetId);
    if (!input) return;
    const isText = input.type === 'text';
    input.type   = isText ? 'password' : 'text';
    const icon   = btn.querySelector('i');
    icon.className = isText ? 'ph ph-eye' : 'ph ph-eye-slash';
  });
});

// ===========================
//  PASSWORD STRENGTH METER
// ===========================
const regPasswordInput = document.getElementById('regPassword');
const pwStrengthBar    = document.getElementById('pwStrengthBar');
const pwStrengthLabel  = document.getElementById('pwStrengthLabel');

const strengthLevels = [
  { label: '',         color: 'transparent', width: '0%'   },
  { label: 'Weak',     color: '#e53e3e',      width: '25%'  },
  { label: 'Fair',     color: '#ed8936',      width: '50%'  },
  { label: 'Good',     color: '#ecc94b',      width: '75%'  },
  { label: 'Strong',   color: '#2ec4b6',      width: '100%' }
];

function calcStrength(pw) {
  let score = 0;
  if (pw.length >= 8)               score++;
  if (/[A-Z]/.test(pw))             score++;
  if (/[0-9]/.test(pw))             score++;
  if (/[^A-Za-z0-9]/.test(pw))     score++;
  return pw.length === 0 ? 0 : Math.max(1, score);
}

if (regPasswordInput) {
  regPasswordInput.addEventListener('input', () => {
    const level = calcStrength(regPasswordInput.value);
    const s     = strengthLevels[level];
    pwStrengthBar.style.width      = s.width;
    pwStrengthBar.style.background = s.color;
    pwStrengthLabel.textContent    = s.label;
    pwStrengthLabel.style.color    = s.color;
  });
}

// ===========================
//  VALIDATION HELPERS
// ===========================
function showError(inputEl, errorEl, message) {
  inputEl.classList.add('invalid');
  errorEl.textContent = message;
}

function clearError(inputEl, errorEl) {
  inputEl.classList.remove('invalid');
  errorEl.textContent = '';
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function setLoading(btn, loading) {
  const text    = btn.querySelector('.btn-text');
  const spinner = btn.querySelector('.btn-spinner');
  if (loading) {
    text.classList.add('hidden');
    spinner.classList.remove('hidden');
    btn.disabled = true;
  } else {
    text.classList.remove('hidden');
    spinner.classList.add('hidden');
    btn.disabled = false;
  }
}

function showSuccess(message) {
  const el  = document.getElementById('authSuccess');
  const msg = document.getElementById('authSuccessMsg');
  if (!el || !msg) return;
  msg.textContent = message;
  el.classList.add('visible');
  setTimeout(() => el.classList.remove('visible'), 4000);
}

// ===========================
//  LOGIN FORM
// ===========================
const loginForm         = document.getElementById('loginForm');
const loginEmailInput   = document.getElementById('loginEmail');
const loginPasswordInput= document.getElementById('loginPassword');
const loginEmailErr     = document.getElementById('loginEmailErr');
const loginPasswordErr  = document.getElementById('loginPasswordErr');
const loginBtn          = document.getElementById('loginBtn');

if (loginForm) {
  // Clear errors on input
  loginEmailInput.addEventListener('input',    () => clearError(loginEmailInput,    loginEmailErr));
  loginPasswordInput.addEventListener('input', () => clearError(loginPasswordInput, loginPasswordErr));

  loginForm.addEventListener('submit', e => {
    e.preventDefault();
    let valid = true;

    const email = loginEmailInput.value.trim();
    const pass  = loginPasswordInput.value;

    if (!email) {
      showError(loginEmailInput, loginEmailErr, 'Email is required.');
      valid = false;
    } else if (!isValidEmail(email)) {
      showError(loginEmailInput, loginEmailErr, 'Please enter a valid email.');
      valid = false;
    }

    if (!pass) {
      showError(loginPasswordInput, loginPasswordErr, 'Password is required.');
      valid = false;
    } else if (pass.length < 6) {
      showError(loginPasswordInput, loginPasswordErr, 'Password must be at least 6 characters.');
      valid = false;
    }

    if (!valid) return;

    setLoading(loginBtn, true);

    // Simulate async auth request
    setTimeout(() => {
      setLoading(loginBtn, false);
      loginForm.reset();
      showSuccess('Welcome back! Redirecting to your dashboard...');
    }, 1600);
  });
}

// ===========================
//  REGISTER FORM
// ===========================
const registerForm      = document.getElementById('registerForm');
const regNameInput      = document.getElementById('regName');
const regEmailInput     = document.getElementById('regEmail');
const regPasswordIn     = document.getElementById('regPassword');
const regConfirmInput   = document.getElementById('regConfirm');
const regNameErr        = document.getElementById('regNameErr');
const regEmailErr       = document.getElementById('regEmailErr');
const regPasswordErr    = document.getElementById('regPasswordErr');
const regConfirmErr     = document.getElementById('regConfirmErr');
const registerBtn       = document.getElementById('registerBtn');

if (registerForm) {
  // Clear errors on input
  regNameInput.addEventListener('input',    () => clearError(regNameInput,    regNameErr));
  regEmailInput.addEventListener('input',   () => clearError(regEmailInput,   regEmailErr));
  regPasswordIn.addEventListener('input',   () => clearError(regPasswordIn,   regPasswordErr));
  regConfirmInput.addEventListener('input', () => clearError(regConfirmInput, regConfirmErr));

  registerForm.addEventListener('submit', e => {
    e.preventDefault();
    let valid = true;

    const name    = regNameInput.value.trim();
    const email   = regEmailInput.value.trim();
    const pass    = regPasswordIn.value;
    const confirm = regConfirmInput.value;

    if (!name || name.length < 2) {
      showError(regNameInput, regNameErr, 'Please enter your full name.');
      valid = false;
    }

    if (!email) {
      showError(regEmailInput, regEmailErr, 'Email is required.');
      valid = false;
    } else if (!isValidEmail(email)) {
      showError(regEmailInput, regEmailErr, 'Please enter a valid email.');
      valid = false;
    }

    if (!pass) {
      showError(regPasswordIn, regPasswordErr, 'Password is required.');
      valid = false;
    } else if (pass.length < 8) {
      showError(regPasswordIn, regPasswordErr, 'Password must be at least 8 characters.');
      valid = false;
    }

    if (!confirm) {
      showError(regConfirmInput, regConfirmErr, 'Please confirm your password.');
      valid = false;
    } else if (pass !== confirm) {
      showError(regConfirmInput, regConfirmErr, 'Passwords do not match.');
      valid = false;
    }

    if (!valid) return;

    setLoading(registerBtn, true);

    // Simulate async account creation
    setTimeout(() => {
      setLoading(registerBtn, false);
      registerForm.reset();
      if (pwStrengthBar)    { pwStrengthBar.style.width = '0%'; pwStrengthBar.style.background = 'transparent'; }
      if (pwStrengthLabel)  { pwStrengthLabel.textContent = ''; }
      showSuccess('Account created successfully! Welcome aboard.');
    }, 1800);
  });
}
