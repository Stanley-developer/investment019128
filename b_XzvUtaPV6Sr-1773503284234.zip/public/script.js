// ===========================
//  AOS INIT
// ===========================
AOS.init({
  once: true,
  offset: 80,
  easing: 'ease-out-cubic',
  duration: 700
});

// ===========================
//  DARK / LIGHT MODE TOGGLE
// ===========================
const html = document.documentElement;
const themeToggles = [
  document.getElementById('themeToggleDesktop'),
  document.getElementById('themeToggleMobile')
];

function setTheme(theme) {
  html.setAttribute('data-theme', theme);
  localStorage.setItem('theme', theme);
  themeToggles.forEach(btn => {
    if (!btn) return;
    const icon = btn.querySelector('.theme-icon-ph');
    if (!icon) return;
    icon.className = theme === 'dark'
      ? 'ph ph-sun theme-icon-ph'
      : 'ph ph-moon theme-icon-ph';
  });
}

(function () {
  const saved = localStorage.getItem('theme') || 'light';
  setTheme(saved);
})();

themeToggles.forEach(btn => {
  if (!btn) return;
  btn.addEventListener('click', () => {
    const current = html.getAttribute('data-theme');
    setTheme(current === 'dark' ? 'light' : 'dark');
  });
});

// ===========================
//  HAMBURGER MENU
// ===========================
const hamburger = document.getElementById('hamburger');
const navLinks  = document.getElementById('navLinks');

const overlay = document.createElement('div');
overlay.classList.add('nav-overlay');
document.body.appendChild(overlay);

function openMenu() {
  navLinks.classList.add('open');
  hamburger.classList.add('open');
  hamburger.setAttribute('aria-expanded', 'true');
  overlay.classList.add('visible');
  document.body.style.overflow = 'hidden';
}

function closeMenu() {
  navLinks.classList.remove('open');
  hamburger.classList.remove('open');
  hamburger.setAttribute('aria-expanded', 'false');
  overlay.classList.remove('visible');
  document.body.style.overflow = '';
}

hamburger.addEventListener('click', () => {
  navLinks.classList.contains('open') ? closeMenu() : openMenu();
});

overlay.addEventListener('click', closeMenu);
navLinks.querySelectorAll('a').forEach(link => link.addEventListener('click', closeMenu));
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeMenu(); });

// ===========================
//  SMOOTH SCROLLING
// ===========================
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', e => {
    const target = document.querySelector(anchor.getAttribute('href'));
    if (!target) return;
    e.preventDefault();
    const navHeight = document.getElementById('navbar').offsetHeight;
    const top = target.getBoundingClientRect().top + window.scrollY - navHeight - 12;
    window.scrollTo({ top, behavior: 'smooth' });
  });
});

// ===========================
//  HERO CAROUSEL SLIDER
// ===========================
const slides = [
  {
    title: 'Investment<br />Company',
    subtitle: 'We help individuals and businesses grow wealth through disciplined, data-driven investment strategies tailored to your financial goals.'
  },
  {
    title: 'Smart Wealth<br />Management',
    subtitle: 'Leverage cutting-edge analytics and expert advisors to optimise your portfolio across global markets with confidence.'
  },
  {
    title: 'Secure Investment<br />Platform',
    subtitle: 'Bank-level security, transparent fees, and real-time reporting so you always know exactly where your money is.'
  },
  {
    title: 'Grow Your<br />Financial Future',
    subtitle: 'Start your journey today with plans from $500. Our team works tirelessly to maximise returns at every investment level.'
  }
];

const heroTitle    = document.getElementById('heroTitle');
const heroSubtitle = document.getElementById('heroSubtitle');
const heroImage    = document.getElementById('heroImage');
const heroContent  = document.querySelector('.hero-content');
const dots         = document.querySelectorAll('.dot');

let currentSlide = 0;
let autoplayTimer = null;

const imageAnimations = [
  'scale(1.55) translateX(8%)',
  'scale(1.6) translateX(4%) translateY(-4%)',
  'scale(1.5) translateX(12%) translateY(4%)',
  'scale(1.65) translateX(6%) translateY(-2%)'
];

function goToSlide(index) {
  if (index === currentSlide) return;

  heroContent.classList.add('slide-out-left');

  setTimeout(() => {
    heroContent.classList.remove('slide-out-left');
    currentSlide = index;

    heroTitle.innerHTML      = slides[index].title;
    heroSubtitle.textContent = slides[index].subtitle;
    heroImage.style.transform = imageAnimations[index];

    dots.forEach((d, i) => d.classList.toggle('active', i === index));

    heroContent.classList.add('slide-in-right');
    setTimeout(() => heroContent.classList.remove('slide-in-right'), 450);
  }, 450);
}

function startAutoplay() {
  stopAutoplay();
  autoplayTimer = setInterval(() => {
    goToSlide((currentSlide + 1) % slides.length);
  }, 5000);
}

function stopAutoplay() {
  if (autoplayTimer) { clearInterval(autoplayTimer); autoplayTimer = null; }
}

dots.forEach((dot, index) => {
  dot.addEventListener('click', () => {
    goToSlide(index);
    stopAutoplay();
    startAutoplay();
  });
});

startAutoplay();

// ===========================
//  TESTIMONIALS SLIDER
// ===========================
const track         = document.getElementById('testimonialsTrack');
const tPrev         = document.getElementById('tPrev');
const tNext         = document.getElementById('tNext');
const tDotsWrap     = document.getElementById('tDots');
const totalCards    = document.querySelectorAll('.testimonial-glass-card').length;
let currentT  = 0;
let tTimer    = null;

for (let i = 0; i < totalCards; i++) {
  const d = document.createElement('button');
  d.classList.add('t-dot');
  d.setAttribute('aria-label', `Testimonial ${i + 1}`);
  if (i === 0) d.classList.add('active');
  d.addEventListener('click', () => { goToTestimonial(i); stopTAutoplay(); startTAutoplay(); });
  tDotsWrap.appendChild(d);
}

function goToTestimonial(index) {
  currentT = (index + totalCards) % totalCards;
  track.style.transform = `translateX(-${currentT * 100}%)`;
  document.querySelectorAll('.t-dot').forEach((d, i) => d.classList.toggle('active', i === currentT));
}

function startTAutoplay() {
  stopTAutoplay();
  tTimer = setInterval(() => goToTestimonial(currentT + 1), 6000);
}

function stopTAutoplay() {
  if (tTimer) { clearInterval(tTimer); tTimer = null; }
}

tPrev.addEventListener('click', () => { goToTestimonial(currentT - 1); stopTAutoplay(); startTAutoplay(); });
tNext.addEventListener('click', () => { goToTestimonial(currentT + 1); stopTAutoplay(); startTAutoplay(); });
startTAutoplay();

// ===========================
//  ANIMATED COUNTERS
// ===========================
function formatStatNumber(value, target) {
  if (target >= 1000000000) {
    const b = value / 1000000000;
    return '$' + (b >= 1 ? b.toFixed(1) : b.toFixed(2)) + 'B';
  }
  if (target >= 1000) return value.toLocaleString() + '+';
  return value + '+';
}

function animateCounter(el) {
  const target    = parseInt(el.getAttribute('data-target'), 10);
  const duration  = 2200;
  const steps     = 70;
  const increment = target / steps;
  let current = 0;
  let step    = 0;

  const timer = setInterval(() => {
    step++;
    current = Math.min(Math.round(increment * step), target);
    el.textContent = formatStatNumber(current, target);
    if (step >= steps) clearInterval(timer);
  }, duration / steps);
}

const statsSection = document.querySelector('.stats-section');
let countersTriggered = false;

const counterObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting && !countersTriggered) {
      countersTriggered = true;
      document.querySelectorAll('.stat-number').forEach(animateCounter);
    }
  });
}, { threshold: 0.3 });

if (statsSection) counterObserver.observe(statsSection);

// ===========================
//  FAQ ACCORDION
// ===========================
document.querySelectorAll('.faq-question').forEach(btn => {
  btn.addEventListener('click', () => {
    const item   = btn.closest('.faq-item');
    const isOpen = item.classList.contains('open');

    document.querySelectorAll('.faq-item').forEach(i => {
      i.classList.remove('open');
      i.querySelector('.faq-question').setAttribute('aria-expanded', 'false');
    });

    if (!isOpen) {
      item.classList.add('open');
      btn.setAttribute('aria-expanded', 'true');
    }
  });
});

// ===========================
//  CONTACT FORM
// ===========================
const contactForm = document.getElementById('contactForm');
const formSuccess = document.getElementById('formSuccess');

if (contactForm) {
  contactForm.addEventListener('submit', e => {
    e.preventDefault();
    const name    = contactForm.querySelector('#name').value.trim();
    const email   = contactForm.querySelector('#email').value.trim();
    const message = contactForm.querySelector('#message').value.trim();

    if (!name || !email || !message) return;

    const btn = contactForm.querySelector('.btn-submit');
    btn.innerHTML = '<i class="ph ph-spinner"></i> Sending...';
    btn.disabled  = true;

    setTimeout(() => {
      contactForm.reset();
      btn.innerHTML = '<i class="ph ph-paper-plane-tilt"></i> Send Message';
      btn.disabled  = false;
      formSuccess.classList.add('visible');
      setTimeout(() => formSuccess.classList.remove('visible'), 4000);
    }, 1400);
  });
}

// ===========================
//  NEWSLETTER FORM
// ===========================
const newsletterForm = document.getElementById('newsletterForm');
if (newsletterForm) {
  newsletterForm.addEventListener('submit', e => {
    e.preventDefault();
    const input = newsletterForm.querySelector('input');
    if (!input.value.trim()) return;
    input.value       = '';
    input.placeholder = 'Thanks for subscribing!';
    setTimeout(() => { input.placeholder = 'Your email address'; }, 3000);
  });
}

// ===========================
//  NAVBAR SCROLL SHADOW
// ===========================
window.addEventListener('scroll', () => {
  const nav = document.getElementById('navbar');
  if (!nav) return;
  nav.style.boxShadow = window.scrollY > 20
    ? '0 2px 28px rgba(0,0,0,0.10)'
    : 'none';
});
