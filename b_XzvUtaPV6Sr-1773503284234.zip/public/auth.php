<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Sign In — Investment Company</title>

  <!-- Fonts (identical to index.html) -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet" />

  <!-- Phosphor Icons (identical to index.html) -->
  <script src="https://unpkg.com/@phosphor-icons/web" defer></script>

  <link rel="stylesheet" href="auth.css" />
</head>
<body>

  <!-- ========================
       NAVBAR
  ======================== -->
  <header class="auth-nav">
    <a href="index.html" class="nav-logo" aria-label="Back to home">
      <span class="logo-dot"></span>
      <span class="logo-text">LOGO</span>
    </a>
    <div class="auth-nav-actions">
      <a href="index.html" class="back-link">
        <i class="ph ph-arrow-left"></i>
        Back to Home
      </a>
      <button class="theme-toggle" id="themeToggle" aria-label="Toggle theme">
        <i class="ph ph-moon theme-icon-ph"></i>
      </button>
    </div>
  </header>

  <!-- ========================
       SPLIT LAYOUT
  ======================== -->
  <main class="auth-layout">

    <!-- LEFT: Fintech hero panel -->
    <aside class="auth-panel">

      <!-- Layered background shapes -->
      <div class="ap-blob ap-blob--1"></div>
      <div class="ap-blob ap-blob--2"></div>
      <div class="ap-ring ap-ring--1"></div>
      <div class="ap-ring ap-ring--2"></div>
      <div class="ap-glow ap-glow--1"></div>
      <div class="ap-glow ap-glow--2"></div>

      <!-- Floating finance shapes -->
      <div class="coin coin--1"><i class="ph ph-currency-dollar"></i></div>
      <div class="coin coin--2"><i class="ph ph-trend-up"></i></div>
      <div class="coin coin--3"><i class="ph ph-currency-btc"></i></div>
      <div class="coin coin--4"><i class="ph ph-chart-line-up"></i></div>

      <!-- Content -->
      <div class="ap-content">
        <!-- Illustration frame — same organic shape as About section -->
        <div class="ap-illustration">
          <div class="ap-ill-inner">
            <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
              <!-- Shield -->
              <path d="M100 20 L160 50 L160 100 C160 140 130 165 100 180 C70 165 40 140 40 100 L40 50 Z"
                    fill="rgba(255,255,255,0.15)" stroke="rgba(255,255,255,0.35)" stroke-width="2"/>
              <!-- Lock body -->
              <rect x="75" y="100" width="50" height="40" rx="8"
                    fill="rgba(255,255,255,0.90)"/>
              <!-- Lock shackle -->
              <path d="M85 100 L85 88 A15 15 0 0 1 115 88 L115 100"
                    fill="none" stroke="rgba(255,255,255,0.90)" stroke-width="6" stroke-linecap="round"/>
              <!-- Keyhole -->
              <circle cx="100" cy="116" r="5" fill="var(--teal-dark)"/>
              <rect x="98" y="116" width="4" height="10" rx="2" fill="var(--teal-dark)"/>
              <!-- Coin stacks -->
              <ellipse cx="48" cy="155" rx="16" ry="6" fill="rgba(255,200,50,0.85)"/>
              <rect x="32" y="135" width="32" height="20" rx="3" fill="rgba(255,200,50,0.70)"/>
              <ellipse cx="48" cy="135" rx="16" ry="6" fill="rgba(255,215,80,0.90)"/>
              <ellipse cx="152" cy="158" rx="12" ry="5" fill="rgba(255,200,50,0.85)"/>
              <rect x="140" y="142" width="24" height="16" rx="3" fill="rgba(255,200,50,0.70)"/>
              <ellipse cx="152" cy="142" rx="12" ry="5" fill="rgba(255,215,80,0.90)"/>
              <!-- Trend arrow -->
              <polyline points="55,80 75,60 90,70 130,45"
                        fill="none" stroke="rgba(255,255,255,0.80)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
              <polygon points="130,45 122,48 127,55" fill="rgba(255,255,255,0.80)"/>
            </svg>
          </div>
          <!-- Floating stat cards (reuse homepage pattern) -->
          <div class="ap-stat ap-stat--1">
            <i class="ph ph-shield-check"></i>
            <div>
              <span class="ap-stat-num">256-bit</span>
              <span class="ap-stat-lbl">Encryption</span>
            </div>
          </div>
          <div class="ap-stat ap-stat--2">
            <i class="ph ph-trend-up"></i>
            <div>
              <span class="ap-stat-num">+32%</span>
              <span class="ap-stat-lbl">Avg. ROI</span>
            </div>
          </div>
        </div>

        <h1 class="ap-headline">Secure Access to Your<br /><span>Investment Dashboard</span></h1>
        <p class="ap-desc">Join 48,000+ investors who trust us to grow and protect their wealth with institutional-grade security.</p>

        <!-- Trust badges -->
        <div class="ap-badges">
          <div class="ap-badge"><i class="ph ph-lock-key"></i> Bank-level security</div>
          <div class="ap-badge"><i class="ph ph-globe"></i> 52 countries</div>
          <div class="ap-badge"><i class="ph ph-medal"></i> CFA certified</div>
        </div>
      </div>
    </aside>

    <!-- RIGHT: Auth container -->
    <section class="auth-container">

      <!-- Background micro-shapes for depth -->
      <div class="ac-blob ac-blob--1"></div>
      <div class="ac-blob ac-blob--2"></div>

      <div class="auth-card">

        <!-- Tab switcher -->
        <div class="auth-tabs" role="tablist" aria-label="Authentication tabs">
          <button class="auth-tab active" id="tabLogin" role="tab" aria-selected="true" aria-controls="panelLogin">
            Login
          </button>
          <button class="auth-tab" id="tabRegister" role="tab" aria-selected="false" aria-controls="panelRegister">
            Register
          </button>
          <div class="tab-indicator" id="tabIndicator"></div>
        </div>

        <!-- ── LOGIN FORM ── -->
        <div class="auth-panel-form active" id="panelLogin" role="tabpanel" aria-labelledby="tabLogin">
          <form id="loginForm" novalidate>

            <!-- Email -->
            <div class="field-wrap">
              <input type="email" id="loginEmail" class="float-input" placeholder=" " autocomplete="email" required />
              <label for="loginEmail" class="float-label">
                <i class="ph ph-envelope"></i> Email Address
              </label>
              <span class="field-error" id="loginEmailErr"></span>
            </div>

            <!-- Password -->
            <div class="field-wrap">
              <input type="password" id="loginPassword" class="float-input" placeholder=" " autocomplete="current-password" required />
              <label for="loginPassword" class="float-label">
                <i class="ph ph-lock"></i> Password
              </label>
              <button type="button" class="pw-toggle" aria-label="Toggle password visibility" data-target="loginPassword">
                <i class="ph ph-eye"></i>
              </button>
              <span class="field-error" id="loginPasswordErr"></span>
            </div>

            <!-- Remember me + Forgot password -->
            <div class="form-row-meta">
              <label class="checkbox-label">
                <input type="checkbox" id="rememberMe" />
                <span class="checkbox-custom"></span>
                Remember me
              </label>
              <a href="#" class="forgot-link">Forgot password?</a>
            </div>

            <!-- Submit -->
            <button type="submit" class="btn-auth" id="loginBtn">
              <span class="btn-text"><i class="ph ph-sign-in"></i> Login</span>
              <span class="btn-spinner hidden"><i class="ph ph-circle-notch spin-icon"></i> Verifying...</span>
            </button>

          </form>
          <p class="auth-switch-text">Don't have an account? <button class="switch-link" data-target="register">Create one</button></p>
        </div>

        <!-- ── REGISTER FORM ── -->
        <div class="auth-panel-form" id="panelRegister" role="tabpanel" aria-labelledby="tabRegister">
          <form id="registerForm" novalidate>

            <!-- Full Name -->
            <div class="field-wrap">
              <input type="text" id="regName" class="float-input" placeholder=" " autocomplete="name" required />
              <label for="regName" class="float-label">
                <i class="ph ph-user"></i> Full Name
              </label>
              <span class="field-error" id="regNameErr"></span>
            </div>

            <!-- Email -->
            <div class="field-wrap">
              <input type="email" id="regEmail" class="float-input" placeholder=" " autocomplete="email" required />
              <label for="regEmail" class="float-label">
                <i class="ph ph-envelope"></i> Email Address
              </label>
              <span class="field-error" id="regEmailErr"></span>
            </div>

            <!-- Password -->
            <div class="field-wrap">
              <input type="password" id="regPassword" class="float-input" placeholder=" " autocomplete="new-password" required />
              <label for="regPassword" class="float-label">
                <i class="ph ph-lock"></i> Password
              </label>
              <button type="button" class="pw-toggle" aria-label="Toggle password visibility" data-target="regPassword">
                <i class="ph ph-eye"></i>
              </button>
              <!-- Password strength bar -->
              <div class="pw-strength">
                <div class="pw-strength-bar" id="pwStrengthBar"></div>
              </div>
              <span class="pw-strength-label" id="pwStrengthLabel"></span>
              <span class="field-error" id="regPasswordErr"></span>
            </div>

            <!-- Confirm Password -->
            <div class="field-wrap">
              <input type="password" id="regConfirm" class="float-input" placeholder=" " autocomplete="new-password" required />
              <label for="regConfirm" class="float-label">
                <i class="ph ph-lock-key"></i> Confirm Password
              </label>
              <button type="button" class="pw-toggle" aria-label="Toggle password visibility" data-target="regConfirm">
                <i class="ph ph-eye"></i>
              </button>
              <span class="field-error" id="regConfirmErr"></span>
            </div>

            <!-- Submit -->
            <button type="submit" class="btn-auth" id="registerBtn">
              <span class="btn-text"><i class="ph ph-user-plus"></i> Create Account</span>
              <span class="btn-spinner hidden"><i class="ph ph-circle-notch spin-icon"></i> Creating...</span>
            </button>

          </form>
          <p class="auth-switch-text">Already have an account? <button class="switch-link" data-target="login">Sign in</button></p>
        </div>

        <!-- Success toast -->
        <div class="auth-success" id="authSuccess" aria-live="polite">
          <i class="ph ph-check-circle"></i>
          <span id="authSuccessMsg">Welcome aboard!</span>
        </div>

      </div>
    </section>

  </main>

  <script src="auth.js"></script>
</body>
</html>
