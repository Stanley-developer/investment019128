/* =============================================
   DASHBOARD.JS — Investment Platform
   Matches design system of index.html + auth.html
============================================= */

/* ---- Theme (synced via localStorage) ---- */
const html = document.documentElement;

function applyTheme(t) {
  html.setAttribute('data-theme', t);
  const icon = document.querySelector('.theme-icon-ph');
  if (icon) {
    icon.className = t === 'dark'
      ? 'ph ph-sun theme-icon-ph'
      : 'ph ph-moon theme-icon-ph';
  }
}

(function initTheme() {
  const saved = localStorage.getItem('theme') || 'light';
  applyTheme(saved);
})();

document.getElementById('themeToggle')?.addEventListener('click', () => {
  const next = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  localStorage.setItem('theme', next);
  applyTheme(next);
});

/* ---- Sidebar collapse / expand ---- */
const sidebar     = document.getElementById('sidebar');
const dashWrapper = document.getElementById('dashWrapper');
const collapseBtn = document.getElementById('sidebarCollapseBtn');
const overlay     = document.getElementById('sbOverlay');
const hamburger   = document.getElementById('dnHamburger');

collapseBtn?.addEventListener('click', () => {
  const isMobile = window.innerWidth <= 768;
  if (isMobile) {
    sidebar.classList.remove('mobile-open');
    overlay.classList.remove('visible');
  } else {
    sidebar.classList.toggle('collapsed');
    dashWrapper.classList.toggle('expanded');
  }
});

hamburger?.addEventListener('click', () => {
  const isMobile = window.innerWidth <= 768;
  if (isMobile) {
    sidebar.classList.toggle('mobile-open');
    overlay.classList.toggle('visible');
  } else {
    sidebar.classList.toggle('collapsed');
    dashWrapper.classList.toggle('expanded');
  }
});

overlay?.addEventListener('click', () => {
  sidebar.classList.remove('mobile-open');
  overlay.classList.remove('visible');
});

/* ---- Active sidebar link highlighting ---- */
const sbLinks = document.querySelectorAll('.sb-link[data-section]');

sbLinks.forEach(link => {
  link.addEventListener('click', function () {
    sbLinks.forEach(l => l.classList.remove('active'));
    this.classList.add('active');
    // close mobile sidebar on nav
    if (window.innerWidth <= 768) {
      sidebar.classList.remove('mobile-open');
      overlay.classList.remove('visible');
    }
  });
});

/* ---- Dropdowns ---- */
function setupDropdown(triggerEl, dropdownEl) {
  if (!triggerEl || !dropdownEl) return;

  triggerEl.addEventListener('click', (e) => {
    e.stopPropagation();
    const isOpen = dropdownEl.classList.contains('open');
    closeAllDropdowns();
    if (!isOpen) dropdownEl.classList.add('open');
  });

  triggerEl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      triggerEl.click();
    }
  });
}

function closeAllDropdowns() {
  document.querySelectorAll('.dn-dropdown').forEach(d => d.classList.remove('open'));
}

setupDropdown(document.getElementById('notifBtn'),   document.getElementById('notifDropdown'));
setupDropdown(document.getElementById('profileBtn'), document.getElementById('profileDropdown'));

document.addEventListener('click', closeAllDropdowns);
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeAllDropdowns(); });

/* Mark all notifications read */
document.querySelector('.dd-mark-read')?.addEventListener('click', () => {
  document.querySelectorAll('.dd-item--unread').forEach(i => i.classList.remove('dd-item--unread'));
  document.querySelector('.dn-badge')?.remove();
});

/* ---- Animated Number Counter ---- */
function animateCounter(el, target, prefix = '$', duration = 1800) {
  const isDecimal = String(target).includes('.');
  const start = 0;
  const startTime = performance.now();

  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    // ease-out-expo
    const eased = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
    const current = start + (target - start) * eased;

    let display;
    if (target >= 1_000_000_000) {
      display = prefix + (current / 1_000_000_000).toFixed(1) + 'B';
    } else if (target >= 1_000_000) {
      display = prefix + (current / 1_000_000).toFixed(1) + 'M';
    } else if (target >= 1_000) {
      display = prefix + Math.round(current).toLocaleString();
    } else {
      display = prefix + Math.round(current);
    }

    el.textContent = display;

    if (progress < 1) requestAnimationFrame(update);
  }

  requestAnimationFrame(update);
}

/* Observe stat cards */
const counterObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;

    const el = entry.target;
    const target = parseFloat(el.dataset.target);
    const prefix = el.dataset.prefix !== undefined ? el.dataset.prefix : '$';

    animateCounter(el, target, prefix);
    counterObserver.unobserve(el);
  });
}, { threshold: 0.4 });

document.querySelectorAll('.sc-number, .ref-stat-num').forEach(el => counterObserver.observe(el));

/* ---- Balance display counter ---- */
function animateBalance() {
  const el = document.getElementById('balanceDisplay');
  if (!el) return;
  animateCounter(el, 38640, '$', 2200);
}

setTimeout(animateBalance, 400);

/* ---- Progress Bars ---- */
const progressObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    const bar = entry.target;
    const pct = bar.dataset.pct;
    setTimeout(() => { bar.style.width = pct + '%'; }, 200);
    progressObserver.unobserve(bar);
  });
}, { threshold: 0.3 });

document.querySelectorAll('.inv-progress-bar').forEach(b => progressObserver.observe(b));

/* ---- Portfolio Chart (Chart.js) ---- */
function buildPortfolioChart(period) {
  const ctx = document.getElementById('portfolioChart');
  if (!ctx) return;

  const datasets = {
    '12m': {
      labels: ['Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar'],
      data:   [22000, 23400, 24100, 23800, 25500, 26200, 27800, 27200, 29500, 31000, 34200, 38640],
    },
    '6m': {
      labels: ['Oct','Nov','Dec','Jan','Feb','Mar'],
      data:   [27800, 27200, 29500, 31000, 34200, 38640],
    },
    '3m': {
      labels: ['Jan','Feb','Mar'],
      data:   [31000, 34200, 38640],
    },
    '1m': {
      labels: ['Week 1','Week 2','Week 3','Week 4'],
      data:   [35200, 36100, 37400, 38640],
    },
  };

  const d = datasets[period] || datasets['12m'];
  const isDark = html.getAttribute('data-theme') === 'dark';
  const gridColor  = isDark ? 'rgba(255,255,255,0.06)' : 'rgba(26,35,64,0.06)';
  const labelColor = isDark ? '#94a3b8' : '#6b7a9a';

  if (window._portfolioChart) {
    window._portfolioChart.data.labels = d.labels;
    window._portfolioChart.data.datasets[0].data = d.data;
    window._portfolioChart.update('active');
    return;
  }

  const gradient = ctx.getContext('2d').createLinearGradient(0, 0, 0, 260);
  gradient.addColorStop(0, 'rgba(46,196,182,0.35)');
  gradient.addColorStop(1, 'rgba(46,196,182,0.00)');

  window._portfolioChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: d.labels,
      datasets: [{
        label: 'Portfolio Value',
        data: d.data,
        borderColor: '#2ec4b6',
        borderWidth: 2.5,
        pointBackgroundColor: '#2ec4b6',
        pointBorderColor: '#fff',
        pointBorderWidth: 2,
        pointRadius: 5,
        pointHoverRadius: 7,
        tension: 0.42,
        fill: true,
        backgroundColor: gradient,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: isDark ? '#1e293b' : '#0f2847',
          titleColor: '#94a3b8',
          bodyColor: '#fff',
          padding: 12,
          cornerRadius: 12,
          callbacks: {
            label: ctx => ' $' + ctx.parsed.y.toLocaleString(),
          },
        },
      },
      scales: {
        x: {
          grid: { color: gridColor },
          ticks: { color: labelColor, font: { family: 'Inter', size: 11 } },
        },
        y: {
          grid: { color: gridColor },
          ticks: {
            color: labelColor,
            font: { family: 'Inter', size: 11 },
            callback: v => '$' + (v / 1000).toFixed(0) + 'k',
          },
        },
      },
    },
  });
}

buildPortfolioChart('12m');

/* Period tab switching */
document.querySelectorAll('.cpt').forEach(btn => {
  btn.addEventListener('click', function () {
    document.querySelectorAll('.cpt').forEach(b => b.classList.remove('active'));
    this.classList.add('active');

    const d = {
      '12m': { labels: ['Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar'], data: [22000,23400,24100,23800,25500,26200,27800,27200,29500,31000,34200,38640] },
      '6m':  { labels: ['Oct','Nov','Dec','Jan','Feb','Mar'], data: [27800,27200,29500,31000,34200,38640] },
      '3m':  { labels: ['Jan','Feb','Mar'], data: [31000,34200,38640] },
      '1m':  { labels: ['Week 1','Week 2','Week 3','Week 4'], data: [35200,36100,37400,38640] },
    }[this.dataset.period];

    if (window._portfolioChart && d) {
      window._portfolioChart.data.labels = d.labels;
      window._portfolioChart.data.datasets[0].data = d.data;
      window._portfolioChart.update('active');
    }
  });
});

/* ---- Sparkline Chart ---- */
function buildSparkline() {
  const ctx = document.getElementById('sparklineChart');
  if (!ctx) return;

  const gradient = ctx.getContext('2d').createLinearGradient(0, 0, 0, 52);
  gradient.addColorStop(0, 'rgba(46,196,182,0.35)');
  gradient.addColorStop(1, 'rgba(46,196,182,0.00)');

  new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['','','','','','','',''],
      datasets: [{
        data: [28000, 29500, 28800, 31000, 30400, 33200, 36100, 38640],
        borderColor: 'rgba(46,196,182,0.9)',
        borderWidth: 1.8,
        pointRadius: 0,
        tension: 0.45,
        fill: true,
        backgroundColor: gradient,
      }],
    },
    options: {
      responsive: false,
      plugins: { legend: { display: false }, tooltip: { enabled: false } },
      scales: { x: { display: false }, y: { display: false } },
      animation: { duration: 1400 },
    },
  });
}

buildSparkline();

/* ---- Referral Copy Button ---- */
const copyBtn   = document.getElementById('refCopyBtn');
const copyIcon  = document.getElementById('refCopyIcon');
const copyLabel = document.getElementById('refCopyLabel');
const copyToast = document.getElementById('refCopiedToast');
const refInput  = document.getElementById('refLinkInput');

copyBtn?.addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(refInput.value);
  } catch {
    refInput.select();
    document.execCommand('copy');
  }

  copyIcon.className = 'ph ph-check';
  copyLabel.textContent = 'Copied!';
  copyBtn.style.background = 'linear-gradient(135deg, #22c55e, #16a34a)';

  copyToast?.classList.add('show');

  setTimeout(() => {
    copyIcon.className = 'ph ph-copy';
    copyLabel.textContent = 'Copy';
    copyBtn.style.background = '';
    copyToast?.classList.remove('show');
  }, 2500);
});

/* ---- Search bar focus animation ---- */
const searchInput = document.getElementById('dnSearch');
searchInput?.addEventListener('focus', () => {
  searchInput.closest('.dn-search-wrap')?.classList.add('focused');
});
searchInput?.addEventListener('blur', () => {
  searchInput.closest('.dn-search-wrap')?.classList.remove('focused');
});

/* ---- AOS Init ---- */
if (typeof AOS !== 'undefined') {
  AOS.init({
    duration: 700,
    once: true,
    easing: 'ease-out-cubic',
    offset: 60,
  });
}

/* ---- Re-render chart on theme change ---- */
const themeObserver = new MutationObserver(() => {
  if (window._portfolioChart) {
    const isDark = html.getAttribute('data-theme') === 'dark';
    const gc = isDark ? 'rgba(255,255,255,0.06)' : 'rgba(26,35,64,0.06)';
    const lc = isDark ? '#94a3b8' : '#6b7a9a';
    window._portfolioChart.options.scales.x.grid.color = gc;
    window._portfolioChart.options.scales.y.grid.color = gc;
    window._portfolioChart.options.scales.x.ticks.color = lc;
    window._portfolioChart.options.scales.y.ticks.color = lc;
    window._portfolioChart.update();
  }
});
themeObserver.observe(html, { attributes: true, attributeFilter: ['data-theme'] });
