/* ============================================================
   WALLET.JS — Wallet Management Page
   Syncs with dashboard.js design system
============================================================ */

const html = document.documentElement;

/* ---- Theme (synced via localStorage) ---- */
function applyTheme(t) {
  html.setAttribute('data-theme', t);
  const icon = document.querySelector('.theme-icon-ph');
  if (icon) icon.className = t === 'dark' ? 'ph ph-sun theme-icon-ph' : 'ph ph-moon theme-icon-ph';
}

(function initTheme() {
  const saved = localStorage.getItem('theme') || 'light';
  applyTheme(saved);
})();

document.getElementById('themeToggle')?.addEventListener('click', () => {
  const next = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  localStorage.setItem('theme', next);
  applyTheme(next);
});

/* ---- Sidebar collapse / expand (identical to dashboard.js) ---- */
const sidebar     = document.getElementById('sidebar');
const dashWrapper = document.getElementById('dashWrapper');
const collapseBtn = document.getElementById('sidebarCollapseBtn');
const overlay     = document.getElementById('sbOverlay');
const hamburger   = document.getElementById('dnHamburger');

collapseBtn?.addEventListener('click', () => {
  if (window.innerWidth <= 768) {
    sidebar.classList.remove('mobile-open');
    overlay.classList.remove('visible');
  } else {
    sidebar.classList.toggle('collapsed');
    dashWrapper.classList.toggle('expanded');
  }
});

hamburger?.addEventListener('click', () => {
  if (window.innerWidth <= 768) {
    sidebar.classList.toggle('mobile-open');
    overlay.classList.toggle('visible');
  } else {
    sidebar.classList.toggle('collapsed');
    dashWrapper.classList.toggle('expanded');
  }
});

overlay?.addEventListener('click', () => {
  sidebar.classList.remove('mobile-open');
  overlay.classList.remove('visible');
});

/* ---- Dropdowns ---- */
function setupDropdown(triggerEl, dropdownEl) {
  if (!triggerEl || !dropdownEl) return;
  triggerEl.addEventListener('click', (e) => {
    e.stopPropagation();
    const isOpen = dropdownEl.classList.contains('open');
    closeAllDropdowns();
    if (!isOpen) dropdownEl.classList.add('open');
  });
  triggerEl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); triggerEl.click(); }
  });
}

function closeAllDropdowns() {
  document.querySelectorAll('.dn-dropdown').forEach(d => d.classList.remove('open'));
}

setupDropdown(document.getElementById('notifBtn'),   document.getElementById('notifDropdown'));
setupDropdown(document.getElementById('profileBtn'), document.getElementById('profileDropdown'));

document.addEventListener('click', closeAllDropdowns);
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeAllDropdowns(); });

document.querySelector('.dd-mark-read')?.addEventListener('click', () => {
  document.querySelectorAll('.dd-item--unread').forEach(i => i.classList.remove('dd-item--unread'));
  document.querySelector('.dn-badge')?.remove();
});

/* ---- Animated Number Counter ---- */
function animateCounter(el, target, prefix = '$', duration = 1800) {
  const startTime = performance.now();
  function update(currentTime) {
    const elapsed   = currentTime - startTime;
    const progress  = Math.min(elapsed / duration, 1);
    const eased     = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
    const current   = target * eased;
    el.textContent  = prefix + Math.round(current).toLocaleString();
    if (progress < 1) requestAnimationFrame(update);
  }
  requestAnimationFrame(update);
}

const counterObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    const el     = entry.target;
    const target = parseFloat(el.dataset.target);
    const prefix = el.dataset.prefix !== undefined ? el.dataset.prefix : '$';
    animateCounter(el, target, prefix);
    counterObserver.unobserve(el);
  });
}, { threshold: 0.4 });

document.querySelectorAll('.wbc-card-value').forEach(el => counterObserver.observe(el));

/* ---- Search bar focus ---- */
const searchInput = document.getElementById('dnSearch');
searchInput?.addEventListener('focus', () => searchInput.closest('.dn-search-wrap')?.classList.add('focused'));
searchInput?.addEventListener('blur',  () => searchInput.closest('.dn-search-wrap')?.classList.remove('focused'));

/* ============================================================
   TAB SWITCHING
============================================================ */
const tabDepositBtn  = document.getElementById('tabDepositBtn');
const tabWithdrawBtn = document.getElementById('tabWithdrawBtn');
const depositPanel   = document.getElementById('depositPanel');
const withdrawPanel  = document.getElementById('withdrawPanel');
const pill           = document.getElementById('wtbPill');

function activateTab(tab) {
  if (tab === 'deposit') {
    tabDepositBtn.classList.add('active');
    tabWithdrawBtn.classList.remove('active');
    depositPanel.classList.add('wallet-panel--active');
    withdrawPanel.classList.remove('wallet-panel--active');
    pill.classList.remove('slide-right');
  } else {
    tabWithdrawBtn.classList.add('active');
    tabDepositBtn.classList.remove('active');
    withdrawPanel.classList.add('wallet-panel--active');
    depositPanel.classList.remove('wallet-panel--active');
    pill.classList.add('slide-right');
  }
  /* Hide any open form area on tab switch */
  hideFormArea('deposit');
  hideFormArea('withdraw');
}

tabDepositBtn?.addEventListener('click',  () => activateTab('deposit'));
tabWithdrawBtn?.addEventListener('click', () => activateTab('withdraw'));

/* ============================================================
   DEPOSIT METHOD SELECTION
============================================================ */
const depositMethodsGrid = document.getElementById('depositMethodsGrid');
const depositFormArea    = document.getElementById('depositFormArea');
const depositQrPanel     = document.getElementById('depositQrPanel');
const depositMethodLabel = document.getElementById('depositMethodLabel');

const CRYPTO_METHODS = ['crypto','usdt-trc20','usdt-erc20','bitcoin','ethereum'];

/* Wallet addresses per method (demo) */
const WALLET_ADDRESSES = {
  'crypto':      'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh',
  'usdt-trc20':  'TRX9MzMpLpxMQzxv1Bj5JmZP4cFfVGHDso',
  'usdt-erc20':  '0x71C7656EC7ab88b098defB751B7401B5f6d8976F',
  'bitcoin':     'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh',
  'ethereum':    '0x71C7656EC7ab88b098defB751B7401B5f6d8976F',
};

let depositQRInstance = null;

function showFormArea(panel) {
  const area    = document.getElementById(panel + 'FormArea');
  const grid    = document.getElementById(panel + 'MethodsGrid');
  const head    = document.querySelector(`#${panel}Panel .wm-methods-head`);
  if (!area) return;
  if (grid) grid.style.display = 'none';
  if (head) head.style.display = 'none';
  area.classList.add('visible');
}

function hideFormArea(panel) {
  const area    = document.getElementById(panel + 'FormArea');
  const grid    = document.getElementById(panel + 'MethodsGrid');
  const head    = document.querySelector(`#${panel}Panel .wm-methods-head`);
  if (!area) return;
  area.classList.remove('visible');
  if (grid) grid.style.display = '';
  if (head) head.style.display = '';
}

function setupMethodCards(gridId, panel) {
  const grid = document.getElementById(gridId);
  if (!grid) return;
  grid.querySelectorAll('.wm-method-card').forEach(card => {
    const btn    = card.querySelector('.wm-method-btn');
    const method = card.dataset.method;
    const name   = card.dataset.name;

    function select() {
      showFormArea(panel);
      const labelEl = document.getElementById(panel + 'MethodLabel');
      if (labelEl) labelEl.textContent = name;

      if (panel === 'deposit') {
        const isCrypto = CRYPTO_METHODS.includes(method);
        if (depositQrPanel) depositQrPanel.style.display = isCrypto ? '' : 'none';
        const walletField = document.getElementById('depositWalletField');
        if (walletField) walletField.style.display = isCrypto ? '' : 'none';

        if (isCrypto) {
          const addr = WALLET_ADDRESSES[method] || WALLET_ADDRESSES['crypto'];
          const addrInput = document.getElementById('depositQrAddr');
          if (addrInput) addrInput.value = addr;

          /* Render QR Code */
          const qrContainer = document.getElementById('depositQrCode');
          if (qrContainer) {
            qrContainer.innerHTML = '';
            if (typeof QRCode !== 'undefined') {
              depositQRInstance = new QRCode(qrContainer, {
                text: addr,
                width: 140,
                height: 140,
                colorDark: '#0f2847',
                colorLight: '#ffffff',
                correctLevel: QRCode.CorrectLevel.M,
              });
            }
          }
        }
      }
    }

    btn?.addEventListener('click', (e) => { e.stopPropagation(); select(); });
    card.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); select(); } });
  });
}

setupMethodCards('depositMethodsGrid',  'deposit');
setupMethodCards('withdrawMethodsGrid', 'withdraw');

/* Back buttons */
document.getElementById('depositBackBtn')?.addEventListener('click',  () => hideFormArea('deposit'));
document.getElementById('withdrawBackBtn')?.addEventListener('click', () => hideFormArea('withdraw'));

/* ============================================================
   COPY WALLET ADDRESS
============================================================ */
document.getElementById('depositCopyAddr')?.addEventListener('click', async () => {
  const val  = document.getElementById('depositQrAddr')?.value || '';
  const icon = document.getElementById('depositCopyIcon');
  try {
    await navigator.clipboard.writeText(val);
  } catch {
    const ta = document.createElement('textarea');
    ta.value = val; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta);
  }
  if (icon) { icon.className = 'ph ph-check'; setTimeout(() => { icon.className = 'ph ph-copy'; }, 2000); }
  showToast('Copied!', 'Wallet address copied to clipboard.', 'success');
});

/* ============================================================
   LIVE DEPOSIT SUMMARY CALCULATION
============================================================ */
const depositAmountInput = document.getElementById('depositAmount');
depositAmountInput?.addEventListener('input', updateDepositSummary);

function updateDepositSummary() {
  const raw  = parseFloat(depositAmountInput?.value) || 0;
  const fee  = raw * 0.005; // 0.5% fee
  const net  = raw - fee;
  document.getElementById('sumDepositAmount').textContent = '$' + raw.toFixed(2);
  document.getElementById('sumDepositFee').textContent    = '$' + fee.toFixed(2);
  document.getElementById('sumDepositTotal').textContent  = '$' + Math.max(0, net).toFixed(2);
}

/* ============================================================
   LIVE WITHDRAW SUMMARY CALCULATION
============================================================ */
const withdrawAmountInput = document.getElementById('withdrawAmount');
withdrawAmountInput?.addEventListener('input', updateWithdrawSummary);

function updateWithdrawSummary() {
  const raw = parseFloat(withdrawAmountInput?.value) || 0;
  const fee = raw * 0.02; // 2% fee
  const net = raw - fee;
  document.getElementById('sumWithdrawAmount').textContent = '$' + raw.toFixed(2);
  document.getElementById('sumWithdrawFee').textContent    = '$' + fee.toFixed(2);
  document.getElementById('sumWithdrawNet').textContent    = '$' + Math.max(0, net).toFixed(2);
}

/* ============================================================
   FILE UPLOAD PREVIEW
============================================================ */
const depositProofInput   = document.getElementById('depositProof');
const depositUploadArea   = document.getElementById('depositUploadArea');
const depositUploadPreview = document.getElementById('depositUploadPreview');

depositProofInput?.addEventListener('change', () => {
  const file = depositProofInput.files[0];
  if (!file) return;
  depositUploadPreview.textContent = `Attached: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`;
  depositUploadArea?.classList.add('wm-upload--has-file');
});

/* ---- Drag and drop ---- */
depositUploadArea?.addEventListener('dragover', (e) => { e.preventDefault(); depositUploadArea.style.borderColor = 'var(--teal)'; });
depositUploadArea?.addEventListener('dragleave', ()  => { depositUploadArea.style.borderColor = ''; });
depositUploadArea?.addEventListener('drop', (e) => {
  e.preventDefault();
  depositUploadArea.style.borderColor = '';
  const file = e.dataTransfer.files[0];
  if (file && depositProofInput) {
    const dt = new DataTransfer();
    dt.items.add(file);
    depositProofInput.files = dt.files;
    depositProofInput.dispatchEvent(new Event('change'));
  }
});

/* ============================================================
   FORM SUBMISSION — DEPOSIT
============================================================ */
document.getElementById('depositForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const amount = parseFloat(document.getElementById('depositAmount')?.value) || 0;
  if (amount < 50) {
    showToast('Error', 'Minimum deposit amount is $50.00.', 'error');
    return;
  }
  await simulateSubmit('depositSubmitBtn');
  showToast('Deposit Submitted!', `Your deposit of $${amount.toFixed(2)} is being processed.`, 'success');
  document.getElementById('depositForm').reset();
  updateDepositSummary();
  hideFormArea('deposit');
});

/* ============================================================
   FORM SUBMISSION — WITHDRAW
============================================================ */
document.getElementById('withdrawForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const amount  = parseFloat(document.getElementById('withdrawAmount')?.value) || 0;
  const address = document.getElementById('withdrawAddress')?.value.trim();
  if (amount < 100) {
    showToast('Error', 'Minimum withdrawal amount is $100.00.', 'error');
    return;
  }
  if (!address) {
    showToast('Error', 'Please enter a destination address.', 'error');
    return;
  }
  await simulateSubmit('withdrawSubmitBtn');
  showToast('Withdrawal Requested!', `Your withdrawal of $${amount.toFixed(2)} has been submitted for review.`, 'success');
  document.getElementById('withdrawForm').reset();
  updateWithdrawSummary();
  hideFormArea('withdraw');
});

/* ---- Simulate async submit with loading state ---- */
function simulateSubmit(btnId) {
  return new Promise(resolve => {
    const btn     = document.getElementById(btnId);
    if (!btn) return resolve();
    const label   = btn.querySelector('.wm-btn-label');
    const spinner = btn.querySelector('.wm-btn-spinner');
    label.hidden   = true;
    spinner.hidden = false;
    btn.disabled   = true;
    setTimeout(() => {
      label.hidden   = false;
      spinner.hidden = true;
      btn.disabled   = false;
      resolve();
    }, 1800);
  });
}

/* ============================================================
   TRANSACTION FILTER
============================================================ */
const filterBtns = document.querySelectorAll('.wt-filter-btn');
const txnRows    = document.querySelectorAll('#txnTableBody tr');

filterBtns.forEach(btn => {
  btn.addEventListener('click', function () {
    filterBtns.forEach(b => b.classList.remove('active'));
    this.classList.add('active');
    const filter = this.dataset.filter;

    txnRows.forEach(row => {
      const type = row.dataset.type;
      if (filter === 'all' || type === filter) {
        row.style.display = '';
      } else {
        row.style.display = 'none';
      }
    });
  });
});

/* ============================================================
   TOAST HELPER
============================================================ */
function showToast(title, msg, type = 'success') {
  const toast    = document.getElementById('walletToast');
  const titleEl  = document.getElementById('walletToastTitle');
  const msgEl    = document.getElementById('walletToastMsg');
  const iconWrap = document.getElementById('walletToastIcon');

  if (!toast) return;
  titleEl.textContent = title;
  msgEl.textContent   = msg;

  if (type === 'error') {
    toast.classList.add('wm-toast--error');
    iconWrap.innerHTML = '<i class="ph ph-x-circle"></i>';
  } else {
    toast.classList.remove('wm-toast--error');
    iconWrap.innerHTML = '<i class="ph ph-check-circle"></i>';
  }

  toast.classList.add('show');
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => toast.classList.remove('show'), 4000);
}

document.getElementById('walletToastClose')?.addEventListener('click', () => {
  document.getElementById('walletToast')?.classList.remove('show');
});

/* ============================================================
   AOS INIT
============================================================ */
if (typeof AOS !== 'undefined') {
  AOS.init({ duration: 700, once: true, easing: 'ease-out-cubic', offset: 60 });
}
