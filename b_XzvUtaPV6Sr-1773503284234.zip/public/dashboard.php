<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dashboard — Investment Company</title>

  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet" />

  <!-- Phosphor Icons -->
  <script src="https://unpkg.com/@phosphor-icons/web" defer></script>

  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

  <!-- AOS -->
  <link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css" />

  <link rel="stylesheet" href="dashboard.css" />
</head>
<body>

  <!-- ===================================================
       SIDEBAR
  =================================================== -->
  <aside class="sidebar" id="sidebar">

    <!-- Sidebar background shapes -->
    <div class="sb-blob sb-blob--1"></div>
    <div class="sb-blob sb-blob--2"></div>
    <div class="sb-ring sb-ring--1"></div>

    <!-- Logo -->
    <div class="sb-logo">
      <span class="logo-dot"></span>
      <span class="logo-text">LOGO</span>
      <button class="sb-collapse-btn" id="sidebarCollapseBtn" aria-label="Collapse sidebar">
        <i class="ph ph-sidebar-simple"></i>
      </button>
    </div>

    <!-- Navigation -->
    <nav class="sb-nav" aria-label="Dashboard navigation">
      <a href="#overview" class="sb-link active" data-section="overview">
        <span class="sb-icon"><i class="ph ph-squares-four"></i></span>
        <span class="sb-label">Dashboard</span>
      </a>
      <a href="#portfolio" class="sb-link" data-section="portfolio">
        <span class="sb-icon"><i class="ph ph-chart-pie-slice"></i></span>
        <span class="sb-label">Portfolio</span>
      </a>
      <a href="#investments" class="sb-link" data-section="investments">
        <span class="sb-icon"><i class="ph ph-trend-up"></i></span>
        <span class="sb-label">Investments</span>
      </a>
      <a href="#transactions" class="sb-link" data-section="transactions">
        <span class="sb-icon"><i class="ph ph-arrows-left-right"></i></span>
        <span class="sb-label">Transactions</span>
      </a>
      <a href="#deposit" class="sb-link" data-section="deposit">
        <span class="sb-icon"><i class="ph ph-arrow-circle-down"></i></span>
        <span class="sb-label">Deposit</span>
      </a>
      <a href="#withdraw" class="sb-link" data-section="withdraw">
        <span class="sb-icon"><i class="ph ph-arrow-circle-up"></i></span>
        <span class="sb-label">Withdraw</span>
      </a>
      <a href="#referrals" class="sb-link" data-section="referrals">
        <span class="sb-icon"><i class="ph ph-users-three"></i></span>
        <span class="sb-label">Referrals</span>
      </a>
      <a href="#settings" class="sb-link" data-section="settings">
        <span class="sb-icon"><i class="ph ph-gear"></i></span>
        <span class="sb-label">Settings</span>
      </a>

      <div class="sb-divider"></div>

      <a href="index.html" class="sb-link sb-logout">
        <span class="sb-icon"><i class="ph ph-sign-out"></i></span>
        <span class="sb-label">Logout</span>
      </a>
    </nav>

    <!-- User mini-profile -->
    <div class="sb-user">
      <div class="sb-avatar">
        <span>JD</span>
        <div class="sb-avatar-ring"></div>
      </div>
      <div class="sb-user-info">
        <span class="sb-user-name">John Doe</span>
        <span class="sb-user-role">Pro Investor</span>
      </div>
    </div>

  </aside>

  <!-- Mobile overlay -->
  <div class="sb-overlay" id="sbOverlay"></div>

  <!-- ===================================================
       MAIN WRAPPER
  =================================================== -->
  <div class="dash-wrapper" id="dashWrapper">

    <!-- ===================================================
         TOP NAVBAR
    =================================================== -->
    <header class="dash-nav">

      <!-- Left: hamburger + page title -->
      <div class="dn-left">
        <button class="dn-hamburger" id="dnHamburger" aria-label="Toggle sidebar">
          <i class="ph ph-list"></i>
        </button>
        <div class="dn-search-wrap">
          <i class="ph ph-magnifying-glass"></i>
          <input type="search" placeholder="Search..." class="dn-search" id="dnSearch" aria-label="Search dashboard" />
        </div>
      </div>

      <!-- Right: actions -->
      <div class="dn-right">

        <!-- Notifications -->
        <div class="dn-action-btn" id="notifBtn" aria-label="Notifications" role="button" tabindex="0">
          <i class="ph ph-bell"></i>
          <span class="dn-badge">3</span>
          <!-- Dropdown -->
          <div class="dn-dropdown notif-dropdown" id="notifDropdown">
            <div class="dd-header">
              <span>Notifications</span>
              <button class="dd-mark-read">Mark all read</button>
            </div>
            <div class="dd-list">
              <div class="dd-item dd-item--unread">
                <div class="dd-item-icon dd-icon-success"><i class="ph ph-check-circle"></i></div>
                <div class="dd-item-body">
                  <p>Deposit of $2,500 confirmed</p>
                  <span>2 min ago</span>
                </div>
              </div>
              <div class="dd-item dd-item--unread">
                <div class="dd-item-icon dd-icon-info"><i class="ph ph-trend-up"></i></div>
                <div class="dd-item-body">
                  <p>Growth Plan profit credited</p>
                  <span>1 hr ago</span>
                </div>
              </div>
              <div class="dd-item dd-item--unread">
                <div class="dd-item-icon dd-icon-warn"><i class="ph ph-warning"></i></div>
                <div class="dd-item-body">
                  <p>Verify your identity to unlock withdrawals</p>
                  <span>Yesterday</span>
                </div>
              </div>
              <div class="dd-item">
                <div class="dd-item-icon dd-icon-success"><i class="ph ph-user-check"></i></div>
                <div class="dd-item-body">
                  <p>New referral joined via your link</p>
                  <span>2 days ago</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Messages -->
        <div class="dn-action-btn" id="msgBtn" aria-label="Messages" role="button" tabindex="0">
          <i class="ph ph-chat-circle-dots"></i>
          <span class="dn-badge dn-badge--teal">2</span>
        </div>

        <!-- Theme toggle -->
        <button class="dn-theme-btn" id="themeToggle" aria-label="Toggle theme">
          <i class="ph ph-moon theme-icon-ph"></i>
        </button>

        <!-- Profile dropdown -->
        <div class="dn-profile-wrap" id="profileWrap">
          <button class="dn-profile-btn" id="profileBtn" aria-label="Profile menu" aria-haspopup="true" aria-expanded="false">
            <div class="dn-avatar">JD</div>
            <span class="dn-profile-name">John Doe</span>
            <i class="ph ph-caret-down"></i>
          </button>
          <div class="dn-dropdown profile-dropdown" id="profileDropdown">
            <a href="#" class="dd-profile-item">
              <i class="ph ph-user"></i> Profile
            </a>
            <a href="#" class="dd-profile-item">
              <i class="ph ph-gear"></i> Settings
            </a>
            <div class="dd-divider"></div>
            <a href="index.html" class="dd-profile-item dd-logout">
              <i class="ph ph-sign-out"></i> Logout
            </a>
          </div>
        </div>

      </div>
    </header>

    <!-- ===================================================
         CONTENT
    =================================================== -->
    <main class="dash-content">

      <!-- =============================================
           SECTION 1 — WELCOME BANNER
      ============================================= -->
      <section class="db-section welcome-section" id="overview">

        <!-- Layered background shapes -->
        <div class="welcome-blob welcome-blob--1"></div>
        <div class="welcome-blob welcome-blob--2"></div>
        <div class="welcome-ring welcome-ring--1"></div>
        <div class="welcome-glow"></div>

        <div class="welcome-inner">
          <div class="welcome-text">
            <span class="welcome-greeting">Good morning,</span>
            <h1 class="welcome-name">Welcome back, Investor <span class="wave-hand">👋</span></h1>
            <p class="welcome-sub">Your portfolio is performing well. Here is your latest overview.</p>
            <div class="welcome-actions">
              <a href="#deposit" class="btn-dash-primary"><i class="ph ph-arrow-circle-down"></i> Deposit</a>
              <a href="#investments" class="btn-dash-outline"><i class="ph ph-trend-up"></i> View Plans</a>
            </div>
          </div>

          <!-- Big balance display -->
          <div class="welcome-balance-card">
            <div class="wbc-ring wbc-ring--1"></div>
            <div class="wbc-ring wbc-ring--2"></div>
            <div class="wbc-glow"></div>
            <span class="wbc-label">Total Portfolio Value</span>
            <div class="wbc-amount" id="balanceDisplay">$0</div>
            <div class="wbc-trend">
              <i class="ph ph-trend-up"></i>
              <span>+$4,280 (12.4%) this month</span>
            </div>
            <!-- Mini sparkline area -->
            <canvas class="wbc-sparkline" id="sparklineChart" aria-label="Portfolio sparkline"></canvas>
          </div>
        </div>

      </section>

      <!-- =============================================
           SECTION 2 — KEY STAT CARDS
      ============================================= -->
      <section class="db-section stats-row-section">

        <!-- Floating shape behind the row -->
        <div class="stat-row-arc"></div>

        <div class="stat-cards-row">

          <div class="stat-card" data-aos="fade-up" data-aos-delay="0">
            <div class="sc-shape sc-shape--1"></div>
            <div class="sc-icon-wrap sc-color--teal"><i class="ph ph-wallet"></i></div>
            <div class="sc-body">
              <span class="sc-label">Total Balance</span>
              <div class="sc-number" data-target="38640">$0</div>
              <div class="sc-trend sc-trend--up"><i class="ph ph-trend-up"></i> +12.4%</div>
            </div>
          </div>

          <div class="stat-card" data-aos="fade-up" data-aos-delay="80">
            <div class="sc-shape sc-shape--2"></div>
            <div class="sc-icon-wrap sc-color--sky"><i class="ph ph-chart-bar"></i></div>
            <div class="sc-body">
              <span class="sc-label">Total Investments</span>
              <div class="sc-number" data-target="25000">$0</div>
              <div class="sc-trend sc-trend--up"><i class="ph ph-trend-up"></i> +3 active plans</div>
            </div>
          </div>

          <div class="stat-card" data-aos="fade-up" data-aos-delay="160">
            <div class="sc-shape sc-shape--3"></div>
            <div class="sc-icon-wrap sc-color--green"><i class="ph ph-coin"></i></div>
            <div class="sc-body">
              <span class="sc-label">Total Profit</span>
              <div class="sc-number" data-target="13640">$0</div>
              <div class="sc-trend sc-trend--up"><i class="ph ph-trend-up"></i> +8.2% this week</div>
            </div>
          </div>

          <div class="stat-card" data-aos="fade-up" data-aos-delay="240">
            <div class="sc-shape sc-shape--4"></div>
            <div class="sc-icon-wrap sc-color--gold"><i class="ph ph-lightning"></i></div>
            <div class="sc-body">
              <span class="sc-label">Active Plans</span>
              <div class="sc-number" data-target="3" data-prefix="">0</div>
              <div class="sc-trend sc-trend--neutral"><i class="ph ph-clock"></i> 2 maturing soon</div>
            </div>
          </div>

        </div>
      </section>

      <!-- =============================================
           SECTION 3 — PORTFOLIO PERFORMANCE CHART
      ============================================= -->
      <section class="db-section chart-section" id="portfolio" data-aos="fade-up">

        <!-- Background shapes -->
        <div class="chart-blob chart-blob--1"></div>
        <div class="chart-ring chart-ring--1"></div>

        <div class="chart-card">
          <div class="chart-card-glow"></div>
          <div class="chart-card-header">
            <div>
              <h2 class="db-section-title">Portfolio Performance</h2>
              <p class="db-section-sub">12-month investment growth overview</p>
            </div>
            <div class="chart-period-tabs">
              <button class="cpt active" data-period="12m">12M</button>
              <button class="cpt" data-period="6m">6M</button>
              <button class="cpt" data-period="3m">3M</button>
              <button class="cpt" data-period="1m">1M</button>
            </div>
          </div>
          <div class="chart-wrap">
            <canvas id="portfolioChart" aria-label="Portfolio performance chart"></canvas>
          </div>
        </div>
      </section>

      <!-- =============================================
           SECTION 4 — ACTIVE INVESTMENTS
      ============================================= -->
      <section class="db-section investments-section" id="investments">

        <div class="inv-section-bg-arc"></div>

        <div class="db-section-head" data-aos="fade-up">
          <h2 class="db-section-title">Active Investments</h2>
          <a href="#pricing" class="db-see-all">View All Plans <i class="ph ph-arrow-right"></i></a>
        </div>

        <div class="inv-cards-grid">

          <div class="inv-card" data-aos="fade-up" data-aos-delay="0">
            <div class="inv-card-glow"></div>
            <div class="inv-card-top">
              <div class="inv-plan-badge inv-badge--starter">Starter</div>
              <span class="inv-status inv-status--active"><i class="ph ph-circle-fill"></i> Active</span>
            </div>
            <div class="inv-card-body">
              <h3>Starter Plan</h3>
              <div class="inv-meta-row">
                <div class="inv-meta"><span>Invested</span><strong>$1,500</strong></div>
                <div class="inv-meta"><span>Duration</span><strong>6 months</strong></div>
                <div class="inv-meta"><span>ROI</span><strong>10% p.a.</strong></div>
              </div>
              <div class="inv-progress-wrap">
                <div class="inv-progress-label">
                  <span>Progress</span>
                  <span class="inv-progress-pct">65%</span>
                </div>
                <div class="inv-progress-track">
                  <div class="inv-progress-bar" data-pct="65"></div>
                </div>
              </div>
              <div class="inv-profit-row">
                <span>Earned so far</span>
                <strong class="inv-profit">+$146.25</strong>
              </div>
            </div>
          </div>

          <div class="inv-card" data-aos="fade-up" data-aos-delay="80">
            <div class="inv-card-glow"></div>
            <div class="inv-card-top">
              <div class="inv-plan-badge inv-badge--growth">Growth</div>
              <span class="inv-status inv-status--active"><i class="ph ph-circle-fill"></i> Active</span>
            </div>
            <div class="inv-card-body">
              <h3>Growth Plan</h3>
              <div class="inv-meta-row">
                <div class="inv-meta"><span>Invested</span><strong>$8,500</strong></div>
                <div class="inv-meta"><span>Duration</span><strong>12 months</strong></div>
                <div class="inv-meta"><span>ROI</span><strong>18% p.a.</strong></div>
              </div>
              <div class="inv-progress-wrap">
                <div class="inv-progress-label">
                  <span>Progress</span>
                  <span class="inv-progress-pct">42%</span>
                </div>
                <div class="inv-progress-track">
                  <div class="inv-progress-bar inv-bar--teal" data-pct="42"></div>
                </div>
              </div>
              <div class="inv-profit-row">
                <span>Earned so far</span>
                <strong class="inv-profit">+$642.60</strong>
              </div>
            </div>
          </div>

          <div class="inv-card" data-aos="fade-up" data-aos-delay="160">
            <div class="inv-card-glow"></div>
            <div class="inv-card-top">
              <div class="inv-plan-badge inv-badge--pro">Pro</div>
              <span class="inv-status inv-status--maturing"><i class="ph ph-circle-fill"></i> Maturing</span>
            </div>
            <div class="inv-card-body">
              <h3>Professional Plan</h3>
              <div class="inv-meta-row">
                <div class="inv-meta"><span>Invested</span><strong>$15,000</strong></div>
                <div class="inv-meta"><span>Duration</span><strong>24 months</strong></div>
                <div class="inv-meta"><span>ROI</span><strong>28% p.a.</strong></div>
              </div>
              <div class="inv-progress-wrap">
                <div class="inv-progress-label">
                  <span>Progress</span>
                  <span class="inv-progress-pct">91%</span>
                </div>
                <div class="inv-progress-track">
                  <div class="inv-progress-bar inv-bar--gold" data-pct="91"></div>
                </div>
              </div>
              <div class="inv-profit-row">
                <span>Earned so far</span>
                <strong class="inv-profit">+$7,560.00</strong>
              </div>
            </div>
          </div>

        </div>
      </section>

      <!-- =============================================
           SECTION 5 — RECENT TRANSACTIONS
      ============================================= -->
      <section class="db-section txn-section" id="transactions" data-aos="fade-up">

        <div class="txn-bg-wave">
          <svg viewBox="0 0 1200 80" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0,40 C300,80 900,0 1200,40 L1200,80 L0,80 Z" fill="var(--txn-wave)" />
          </svg>
        </div>
        <div class="txn-bg-ring txn-bg-ring--1"></div>

        <div class="db-section-head">
          <h2 class="db-section-title">Recent Transactions</h2>
          <a href="#" class="db-see-all">View All <i class="ph ph-arrow-right"></i></a>
        </div>

        <div class="txn-card">
          <div class="txn-card-glow"></div>
          <div class="txn-table-wrap">
            <table class="txn-table" aria-label="Recent transactions">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Type</th>
                  <th>Amount</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><span class="txn-date">Mar 13, 2026</span></td>
                  <td><span class="txn-type txn-type--deposit"><i class="ph ph-arrow-circle-down"></i> Deposit</span></td>
                  <td><span class="txn-amount txn-amount--pos">+$2,500.00</span></td>
                  <td><span class="txn-badge txn-badge--completed">Completed</span></td>
                </tr>
                <tr>
                  <td><span class="txn-date">Mar 11, 2026</span></td>
                  <td><span class="txn-type txn-type--profit"><i class="ph ph-coin"></i> Profit</span></td>
                  <td><span class="txn-amount txn-amount--pos">+$186.40</span></td>
                  <td><span class="txn-badge txn-badge--completed">Completed</span></td>
                </tr>
                <tr>
                  <td><span class="txn-date">Mar 8, 2026</span></td>
                  <td><span class="txn-type txn-type--withdrawal"><i class="ph ph-arrow-circle-up"></i> Withdrawal</span></td>
                  <td><span class="txn-amount txn-amount--neg">-$1,000.00</span></td>
                  <td><span class="txn-badge txn-badge--pending">Pending</span></td>
                </tr>
                <tr>
                  <td><span class="txn-date">Mar 5, 2026</span></td>
                  <td><span class="txn-type txn-type--investment"><i class="ph ph-trend-up"></i> Investment</span></td>
                  <td><span class="txn-amount txn-amount--neg">-$8,500.00</span></td>
                  <td><span class="txn-badge txn-badge--completed">Completed</span></td>
                </tr>
                <tr>
                  <td><span class="txn-date">Feb 28, 2026</span></td>
                  <td><span class="txn-type txn-type--profit"><i class="ph ph-coin"></i> Profit</span></td>
                  <td><span class="txn-amount txn-amount--pos">+$312.75</span></td>
                  <td><span class="txn-badge txn-badge--completed">Completed</span></td>
                </tr>
                <tr>
                  <td><span class="txn-date">Feb 20, 2026</span></td>
                  <td><span class="txn-type txn-type--deposit"><i class="ph ph-arrow-circle-down"></i> Deposit</span></td>
                  <td><span class="txn-amount txn-amount--pos">+$5,000.00</span></td>
                  <td><span class="txn-badge txn-badge--failed">Failed</span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

      </section>

      <!-- =============================================
           SECTION 6 — QUICK ACTIONS
      ============================================= -->
      <section class="db-section quick-section" id="deposit">

        <div class="quick-bg-shape"></div>
        <div class="quick-glow"></div>

        <div class="db-section-head" data-aos="fade-up">
          <h2 class="db-section-title">Quick Actions</h2>
        </div>

        <div class="quick-grid">

          <a href="#deposit" class="quick-card quick-card--deposit" data-aos="zoom-in" data-aos-delay="0">
            <div class="qc-ring qc-ring--1"></div>
            <div class="qc-icon"><i class="ph ph-arrow-circle-down"></i></div>
            <h3>Deposit Funds</h3>
            <p>Add funds to your investment account securely</p>
            <span class="qc-arrow"><i class="ph ph-arrow-right"></i></span>
          </a>

          <a href="#withdraw" class="quick-card quick-card--withdraw" data-aos="zoom-in" data-aos-delay="80">
            <div class="qc-ring qc-ring--2"></div>
            <div class="qc-icon"><i class="ph ph-arrow-circle-up"></i></div>
            <h3>Withdraw Funds</h3>
            <p>Transfer your profits and balance to your bank</p>
            <span class="qc-arrow"><i class="ph ph-arrow-right"></i></span>
          </a>

          <a href="#investments" class="quick-card quick-card--invest" data-aos="zoom-in" data-aos-delay="160">
            <div class="qc-ring qc-ring--3"></div>
            <div class="qc-icon"><i class="ph ph-trend-up"></i></div>
            <h3>View Investments</h3>
            <p>Browse available plans and manage your portfolio</p>
            <span class="qc-arrow"><i class="ph ph-arrow-right"></i></span>
          </a>

          <a href="#referrals" class="quick-card quick-card--refer" data-aos="zoom-in" data-aos-delay="240">
            <div class="qc-ring qc-ring--4"></div>
            <div class="qc-icon"><i class="ph ph-share-network"></i></div>
            <h3>Invite Friends</h3>
            <p>Share your referral link and earn commissions</p>
            <span class="qc-arrow"><i class="ph ph-arrow-right"></i></span>
          </a>

        </div>
      </section>

      <!-- =============================================
           SECTION 7 — REFERRAL PROGRAM
      ============================================= -->
      <section class="db-section referral-section" id="referrals" data-aos="fade-up">

        <div class="ref-blob ref-blob--1"></div>
        <div class="ref-blob ref-blob--2"></div>
        <div class="ref-ring ref-ring--1"></div>

        <div class="referral-card">
          <div class="ref-card-glow"></div>

          <div class="ref-left">
            <!-- SVG illustration of two linked people -->
            <div class="ref-illustration">
              <svg viewBox="0 0 180 140" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                <!-- Person 1 -->
                <circle cx="40" cy="38" r="18" fill="rgba(255,255,255,0.25)" stroke="rgba(255,255,255,0.5)" stroke-width="2"/>
                <circle cx="40" cy="32" r="10" fill="rgba(255,255,255,0.6)"/>
                <path d="M18 72 Q40 58 62 72 L62 95 Q40 100 18 95 Z" fill="rgba(255,255,255,0.4)"/>
                <!-- Person 2 -->
                <circle cx="140" cy="38" r="18" fill="rgba(255,255,255,0.25)" stroke="rgba(255,255,255,0.5)" stroke-width="2"/>
                <circle cx="140" cy="32" r="10" fill="rgba(255,255,255,0.6)"/>
                <path d="M118 72 Q140 58 162 72 L162 95 Q140 100 118 95 Z" fill="rgba(255,255,255,0.4)"/>
                <!-- Link chain -->
                <line x1="62" y1="72" x2="88" y2="72" stroke="rgba(255,255,255,0.6)" stroke-width="3" stroke-dasharray="5,3"/>
                <circle cx="90" cy="72" r="8" fill="rgba(255,255,255,0.35)" stroke="rgba(255,255,255,0.6)" stroke-width="2"/>
                <line x1="98" y1="72" x2="118" y2="72" stroke="rgba(255,255,255,0.6)" stroke-width="3" stroke-dasharray="5,3"/>
                <text x="87" y="76" font-size="9" fill="rgba(255,255,255,0.9)" font-family="Poppins,sans-serif" font-weight="700">$</text>
                <!-- Coin bursts -->
                <circle cx="40" cy="118" r="6" fill="rgba(255,200,50,0.85)"/>
                <circle cx="90" cy="125" r="5" fill="rgba(255,200,50,0.70)"/>
                <circle cx="140" cy="118" r="6" fill="rgba(255,200,50,0.85)"/>
              </svg>
            </div>

            <h2>Referral Program</h2>
            <p>Invite friends and earn <strong>5% commission</strong> on every successful investment they make.</p>

            <div class="ref-stats-row">
              <div class="ref-stat">
                <span class="ref-stat-num" data-target="12">0</span>
                <span class="ref-stat-lbl">Total Referrals</span>
              </div>
              <div class="ref-stat">
                <span class="ref-stat-num" data-prefix="$" data-target="840">0</span>
                <span class="ref-stat-lbl">Referral Earnings</span>
              </div>
            </div>
          </div>

          <div class="ref-right">
            <span class="ref-label">Your Referral Link</span>
            <div class="ref-link-box">
              <input type="text" class="ref-link-input" id="refLinkInput" value="https://invest.co/ref/JohnDoe2024" readonly aria-label="Referral link" />
              <button class="ref-copy-btn" id="refCopyBtn" aria-label="Copy referral link">
                <i class="ph ph-copy" id="refCopyIcon"></i>
                <span id="refCopyLabel">Copy</span>
              </button>
            </div>
            <div class="ref-copied-toast" id="refCopiedToast">
              <i class="ph ph-check-circle"></i> Link copied to clipboard!
            </div>
            <div class="ref-share-row">
              <span>Share via:</span>
              <button class="ref-share-btn" aria-label="Share on WhatsApp"><i class="ph ph-whatsapp-logo"></i></button>
              <button class="ref-share-btn" aria-label="Share on Twitter/X"><i class="ph ph-x-logo"></i></button>
              <button class="ref-share-btn" aria-label="Share on Telegram"><i class="ph ph-telegram-logo"></i></button>
            </div>
          </div>

        </div>
      </section>

      <!-- =============================================
           SECTION 8 — ACTIVITY TIMELINE
      ============================================= -->
      <section class="db-section timeline-section" data-aos="fade-up">

        <div class="tls-bg-arc"></div>
        <div class="tls-glow"></div>

        <div class="db-section-head">
          <h2 class="db-section-title">Recent Activity</h2>
          <a href="#" class="db-see-all">View All <i class="ph ph-arrow-right"></i></a>
        </div>

        <div class="activity-timeline">

          <div class="atl-item">
            <div class="atl-icon atl-icon--success"><i class="ph ph-arrow-circle-down"></i></div>
            <div class="atl-line"></div>
            <div class="atl-card">
              <div class="atl-card-header">
                <strong>Deposit Confirmed</strong>
                <span class="atl-time">Today, 09:14</span>
              </div>
              <p>$2,500 successfully deposited to your account via bank transfer.</p>
              <span class="atl-tag atl-tag--success">Completed</span>
            </div>
          </div>

          <div class="atl-item">
            <div class="atl-icon atl-icon--teal"><i class="ph ph-trend-up"></i></div>
            <div class="atl-line"></div>
            <div class="atl-card">
              <div class="atl-card-header">
                <strong>Investment Started</strong>
                <span class="atl-time">Yesterday, 14:30</span>
              </div>
              <p>Growth Plan investment of $8,500 activated. Duration: 12 months.</p>
              <span class="atl-tag atl-tag--teal">Active</span>
            </div>
          </div>

          <div class="atl-item">
            <div class="atl-icon atl-icon--warn"><i class="ph ph-arrow-circle-up"></i></div>
            <div class="atl-line"></div>
            <div class="atl-card">
              <div class="atl-card-header">
                <strong>Withdrawal Processing</strong>
                <span class="atl-time">Mar 8, 16:02</span>
              </div>
              <p>Withdrawal request of $1,000 is currently being processed.</p>
              <span class="atl-tag atl-tag--warn">Pending</span>
            </div>
          </div>

          <div class="atl-item">
            <div class="atl-icon atl-icon--gold"><i class="ph ph-coin"></i></div>
            <div class="atl-line"></div>
            <div class="atl-card">
              <div class="atl-card-header">
                <strong>Profit Credited</strong>
                <span class="atl-time">Mar 5, 08:00</span>
              </div>
              <p>Monthly profit of $312.75 credited from Professional Plan.</p>
              <span class="atl-tag atl-tag--success">Completed</span>
            </div>
          </div>

          <div class="atl-item">
            <div class="atl-icon atl-icon--info"><i class="ph ph-user-plus"></i></div>
            <div class="atl-card">
              <div class="atl-card-header">
                <strong>Referral Joined</strong>
                <span class="atl-time">Mar 2, 11:45</span>
              </div>
              <p>A new investor joined via your referral link. Commission: $25.00.</p>
              <span class="atl-tag atl-tag--info">Referral</span>
            </div>
          </div>

        </div>
      </section>

    </main>
  </div>

  <!-- AOS -->
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script src="dashboard.js"></script>
</body>
</html>
