/* ===================================================
   plans.js — Investment Plans page logic
   Matches design system from dashboard/wallet pages
=================================================== */

/* ===========================
   THEME SYNC (localStorage)
=========================== */
(function () {
  const stored = localStorage.getItem('theme') || 'light';
  document.documentElement.setAttribute('data-theme', stored);
})();

document.addEventListener('DOMContentLoaded', () => {

  /* ===========================
     THEME TOGGLE
  =========================== */
  const themeToggle = document.getElementById('themeToggle');
  const themeIcon   = themeToggle ? themeToggle.querySelector('.theme-icon-ph') : null;

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
    if (themeIcon) {
      themeIcon.className = theme === 'dark' ? 'ph ph-sun theme-icon-ph' : 'ph ph-moon theme-icon-ph';
    }
  }

  if (themeToggle) {
    applyTheme(localStorage.getItem('theme') || 'light');
    themeToggle.addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme');
      applyTheme(current === 'dark' ? 'light' : 'dark');
    });
  }

  /* ===========================
     SIDEBAR — collapse / mobile
  =========================== */
  const sidebar         = document.getElementById('sidebar');
  const dashWrapper     = document.getElementById('dashWrapper');
  const sidebarCollapse = document.getElementById('sidebarCollapseBtn');
  const dnHamburger     = document.getElementById('dnHamburger');
  const sbOverlay       = document.getElementById('sbOverlay');
  const isMobile        = () => window.innerWidth <= 768;

  if (sidebarCollapse) {
    sidebarCollapse.addEventListener('click', () => {
      if (isMobile()) return;
      sidebar.classList.toggle('collapsed');
      dashWrapper.classList.toggle('expanded');
    });
  }

  function openMobileSidebar() {
    sidebar.classList.add('mobile-open');
    sbOverlay.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
  function closeMobileSidebar() {
    sidebar.classList.remove('mobile-open');
    sbOverlay.classList.remove('active');
    document.body.style.overflow = '';
  }

  if (dnHamburger)  dnHamburger.addEventListener('click', openMobileSidebar);
  if (sbOverlay)    sbOverlay.addEventListener('click', closeMobileSidebar);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeMobileSidebar(); });

  /* ===========================
     DROPDOWNS (notif + profile)
  =========================== */
  const notifBtn        = document.getElementById('notifBtn');
  const notifDropdown   = document.getElementById('notifDropdown');
  const profileBtn      = document.getElementById('profileBtn');
  const profileDropdown = document.getElementById('profileDropdown');

  function closeAllDropdowns() {
    notifDropdown?.classList.remove('open');
    profileDropdown?.classList.remove('open');
    profileBtn?.setAttribute('aria-expanded', 'false');
  }

  notifBtn?.addEventListener('click', e => {
    e.stopPropagation();
    const isOpen = notifDropdown.classList.contains('open');
    closeAllDropdowns();
    if (!isOpen) notifDropdown.classList.add('open');
  });

  profileBtn?.addEventListener('click', e => {
    e.stopPropagation();
    const isOpen = profileDropdown.classList.contains('open');
    closeAllDropdowns();
    if (!isOpen) {
      profileDropdown.classList.add('open');
      profileBtn.setAttribute('aria-expanded', 'true');
    }
  });

  document.addEventListener('click', closeAllDropdowns);

  /* ===========================
     ANIMATED COUNTERS
  =========================== */
  function animateCounter(el) {
    const target  = parseFloat(el.dataset.target) || 0;
    const prefix  = el.dataset.prefix !== undefined ? el.dataset.prefix : '$';
    const duration = 1800;
    const start    = performance.now();

    function update(now) {
      const elapsed  = now - start;
      const progress = Math.min(elapsed / duration, 1);
      const ease     = 1 - Math.pow(1 - progress, 4);
      const value    = target * ease;
      el.textContent = prefix + (Number.isInteger(target)
        ? Math.round(value).toLocaleString()
        : value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
      if (progress < 1) requestAnimationFrame(update);
    }
    requestAnimationFrame(update);
  }

  const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting && !entry.target.dataset.counted) {
        entry.target.dataset.counted = '1';
        animateCounter(entry.target);
      }
    });
  }, { threshold: 0.4 });

  document.querySelectorAll('[data-target]').forEach(el => counterObserver.observe(el));

  /* ===========================
     PROGRESS BARS ANIMATION
  =========================== */
  const progressObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const bars = entry.target.querySelectorAll('[data-pct]');
        bars.forEach(bar => {
          setTimeout(() => {
            bar.style.width = bar.dataset.pct + '%';
          }, 200);
        });
        progressObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.3 });

  document.querySelectorAll('.ai-card, .ai-cards-grid').forEach(el => progressObserver.observe(el));

  /* ===========================
     PROFIT SIMULATOR
  =========================== */
  const simPlan    = document.getElementById('simPlan');
  const simAmount  = document.getElementById('simAmount');
  const simDaily   = document.getElementById('simDaily');
  const simTotal   = document.getElementById('simTotal');
  const simProfit  = document.getElementById('simProfit');
  const simROI     = document.getElementById('simROI');
  const simBarFill = document.getElementById('simBarFill');
  const simBarPct  = document.getElementById('simBarPct');

  function updateSimulator() {
    const rate   = parseFloat(simPlan?.value || '1.5') / 100;
    const amount = parseFloat(simAmount?.value || '0');
    if (isNaN(amount) || amount <= 0) {
      ['simDaily','simTotal','simProfit'].forEach(id => { const el = document.getElementById(id); if(el) el.textContent = '$0.00'; });
      if (simROI) simROI.textContent = '0%';
      if (simBarFill) simBarFill.style.width = '0%';
      if (simBarPct) simBarPct.textContent = '0%';
      return;
    }
    const daily   = amount * rate;
    const total   = amount + (daily * 100);
    const profit  = daily * 100;
    const roi     = (profit / amount) * 100;
    const barPct  = Math.min(roi / 400, 1) * 100;

    if (simDaily)  simDaily.textContent  = '$' + daily.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
    if (simTotal)  simTotal.textContent  = '$' + total.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
    if (simProfit) simProfit.textContent = '$' + profit.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
    if (simROI)    simROI.textContent    = roi.toFixed(0) + '%';
    if (simBarFill){ simBarFill.style.width = barPct + '%'; }
    if (simBarPct) simBarPct.textContent = roi.toFixed(0) + '%';
  }

  simPlan?.addEventListener('change', updateSimulator);
  simAmount?.addEventListener('input', updateSimulator);

  /* ===========================
     DAILY CLAIM
  =========================== */
  const claimBtn      = document.getElementById('claimBtn');
  const cpCountdown   = document.getElementById('cpCountdown');
  const cpStatusRing  = document.getElementById('cpStatusRing');
  const cpLastClaim   = document.getElementById('cpLastClaim');
  const countdownTimer= document.getElementById('countdownTimer');

  const CLAIM_KEY = 'lastClaimTime';
  let countdownInterval = null;

  function isClaimed() {
    const last = localStorage.getItem(CLAIM_KEY);
    if (!last) return false;
    const diff = Date.now() - parseInt(last, 10);
    return diff < 24 * 60 * 60 * 1000;
  }

  function formatTime(ms) {
    const totalSec = Math.max(0, Math.floor(ms / 1000));
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    return [h, m, s].map(n => String(n).padStart(2, '0')).join(':');
  }

  function startCountdown() {
    const last = parseInt(localStorage.getItem(CLAIM_KEY) || '0', 10);
    const reset = last + 24 * 60 * 60 * 1000;

    if (countdownInterval) clearInterval(countdownInterval);
    countdownInterval = setInterval(() => {
      const remaining = reset - Date.now();
      if (remaining <= 0) {
        clearInterval(countdownInterval);
        resetClaimState();
      } else {
        if (countdownTimer) countdownTimer.textContent = formatTime(remaining);
      }
    }, 1000);

    if (countdownTimer) countdownTimer.textContent = formatTime(reset - Date.now());
  }

  function setClaimedState() {
    if (claimBtn) { claimBtn.disabled = true; claimBtn.querySelector('span')?.setAttribute('style',''); }
    if (cpCountdown) cpCountdown.style.display = 'flex';
    if (cpStatusRing) cpStatusRing.classList.add('claimed');
    const last = parseInt(localStorage.getItem(CLAIM_KEY) || '0', 10);
    if (cpLastClaim && last) {
      cpLastClaim.textContent = new Date(last).toLocaleTimeString('en-US', { hour:'2-digit', minute:'2-digit' });
    }
    startCountdown();
  }

  function resetClaimState() {
    if (claimBtn) { claimBtn.disabled = false; }
    if (cpCountdown) cpCountdown.style.display = 'none';
    if (cpStatusRing) cpStatusRing.classList.remove('claimed');
    if (cpLastClaim) cpLastClaim.textContent = 'Not yet claimed today';
  }

  if (isClaimed()) {
    setClaimedState();
  }

  claimBtn?.addEventListener('click', () => {
    if (isClaimed()) return;
    const amount = document.getElementById('claimAmount')?.textContent || '367.50';
    localStorage.setItem(CLAIM_KEY, Date.now().toString());
    setClaimedState();
    showToast('Reward Claimed!', `$${amount} has been added to your wallet.`, 'success');
  });

  /* ===========================
     INVESTMENT MODAL
  =========================== */
  const investModal    = document.getElementById('investModal');
  const modalClose     = document.getElementById('modalClose');
  const modalCancel    = document.getElementById('modalCancel');
  const modalInvestBtn = document.getElementById('modalInvestBtn');
  const modalAmount    = document.getElementById('modalAmount');
  const modalBadge     = document.getElementById('modalBadge');
  const modalTitle     = document.getElementById('modalTitle');
  const modalSub       = document.getElementById('modalSub');
  const modalAmountHint= document.getElementById('modalAmountHint');
  const modalIconWrap  = document.getElementById('modalIconWrap');
  const mpDaily        = document.getElementById('mpDaily');
  const mpTotal        = document.getElementById('mpTotal');
  const mpProfit       = document.getElementById('mpProfit');

  let currentPlan = { name:'', min:0, max:0, daily:0 };

  const planIconMap = { Starter:'ph ph-plant', Growth:'ph ph-chart-line-up', Premium:'ph ph-crown' };
  const planColorMap = {
    Starter:{ badge:'rgba(91,200,232,.12)', color:'var(--sky)' },
    Growth: { badge:'rgba(46,196,182,.12)', color:'var(--teal)' },
    Premium:{ badge:'rgba(245,158,11,.12)', color:'var(--gold)' },
  };

  function openModal(plan, min, max, daily) {
    currentPlan = { name:plan, min, max, daily };
    if (modalBadge) {
      modalBadge.textContent = plan;
      const c = planColorMap[plan] || planColorMap.Growth;
      modalBadge.style.background = c.badge;
      modalBadge.style.color = c.color;
    }
    if (modalTitle) modalTitle.textContent = `Invest in ${plan} Plan`;
    if (modalSub) modalSub.textContent = `Daily reward: ${daily}% for 100 days — Total return: 300%`;
    if (modalAmountHint) modalAmountHint.textContent = `Min: $${min.toLocaleString()} — Max: ${max >= 999999 ? 'Unlimited' : '$' + max.toLocaleString()}`;
    if (modalIconWrap) {
      const icon = planIconMap[plan] || planIconMap.Growth;
      modalIconWrap.innerHTML = `<i class="${icon}"></i>`;
    }
    if (modalAmount) { modalAmount.value = ''; }
    updateModalProjection(0);
    investModal?.classList.add('open');
    document.body.style.overflow = 'hidden';
    setTimeout(() => modalAmount?.focus(), 300);
  }

  function closeModal() {
    investModal?.classList.remove('open');
    document.body.style.overflow = '';
  }

  function updateModalProjection(amount) {
    const rate  = currentPlan.daily / 100;
    const daily = amount * rate;
    const total = amount + daily * 100;
    const profit= daily * 100;
    const fmt   = n => '$' + n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
    if (mpDaily)  mpDaily.textContent  = fmt(daily);
    if (mpTotal)  mpTotal.textContent  = fmt(total);
    if (mpProfit) mpProfit.textContent = fmt(profit);
  }

  modalAmount?.addEventListener('input', () => {
    const val = parseFloat(modalAmount.value) || 0;
    updateModalProjection(val);
  });

  document.querySelectorAll('.pc-invest-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const plan  = btn.dataset.plan;
      const min   = parseFloat(btn.dataset.min);
      const max   = parseFloat(btn.dataset.max);
      const daily = parseFloat(btn.dataset.daily);
      openModal(plan, min, max, daily);
    });
  });

  modalClose?.addEventListener('click', closeModal);
  modalCancel?.addEventListener('click', closeModal);
  investModal?.addEventListener('click', e => { if (e.target === investModal) closeModal(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && investModal?.classList.contains('open')) closeModal(); });

  modalInvestBtn?.addEventListener('click', () => {
    const amount = parseFloat(modalAmount?.value || '0');
    if (!amount || amount < currentPlan.min) {
      showToast('Invalid Amount', `Minimum investment for ${currentPlan.name} is $${currentPlan.min.toLocaleString()}.`, 'error');
      return;
    }
    if (amount > currentPlan.max) {
      showToast('Invalid Amount', `Maximum investment for ${currentPlan.name} is $${currentPlan.max.toLocaleString()}.`, 'error');
      return;
    }

    // Show spinner
    const btnText    = modalInvestBtn.querySelector('.modal-btn-text');
    const btnSpinner = modalInvestBtn.querySelector('.modal-btn-spinner');
    btnText.style.display    = 'none';
    btnSpinner.style.display = 'flex';
    modalInvestBtn.disabled  = true;

    setTimeout(() => {
      btnText.style.display    = '';
      btnSpinner.style.display = 'none';
      modalInvestBtn.disabled  = false;
      closeModal();
      showToast('Investment Confirmed!', `$${amount.toLocaleString()} invested in ${currentPlan.name} Plan. Earning ${currentPlan.daily}% daily.`, 'success');
    }, 2000);
  });

  /* ===========================
     TOAST
  =========================== */
  const plansToast = document.getElementById('plansToast');
  const ptTitle    = document.getElementById('ptTitle');
  const ptMsg      = document.getElementById('ptMsg');
  const ptIcon     = document.getElementById('ptIcon');
  const ptClose    = document.getElementById('ptClose');
  let toastTimeout = null;

  function showToast(title, msg, type = 'success') {
    if (!plansToast) return;
    if (ptTitle) ptTitle.textContent = title;
    if (ptMsg)   ptMsg.textContent   = msg;
    if (ptIcon)  ptIcon.innerHTML    = type === 'success'
      ? '<i class="ph ph-check-circle"></i>'
      : '<i class="ph ph-x-circle"></i>';

    plansToast.classList.toggle('error', type === 'error');
    plansToast.classList.add('show');

    if (toastTimeout) clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => plansToast.classList.remove('show'), 5000);
  }

  ptClose?.addEventListener('click', () => {
    plansToast?.classList.remove('show');
    if (toastTimeout) clearTimeout(toastTimeout);
  });

  /* ===========================
     EARNINGS CHART
  =========================== */
  const earningsCtx = document.getElementById('earningsChart')?.getContext('2d');

  function buildChartData(type) {
    const labels = Array.from({ length: 100 }, (_, i) => `Day ${i + 1}`).filter((_, i) => i % 10 === 0 || i === 99);
    const dailyBase = [11.25, 12.50, 11.80, 13.20, 12.90, 14.00, 13.50, 15.20, 14.80, 15.60];
    const expanded  = [];
    for (let i = 0; i < 100; i++) {
      expanded.push(dailyBase[Math.floor(i / 10)] + (Math.random() * 2 - 1));
    }
    const filtered = expanded.filter((_, i) => i % 10 === 0 || i === 99);

    if (type === 'daily') return { labels, data: filtered };

    let cumulative = 0;
    const cumData = expanded.map(v => { cumulative += v; return cumulative; });
    return { labels, data: cumData.filter((_, i) => i % 10 === 0 || i === 99) };
  }

  let earningsChart = null;

  function renderEarningsChart(type) {
    if (!earningsCtx) return;
    const { labels, data } = buildChartData(type);

    const isDark  = document.documentElement.getAttribute('data-theme') === 'dark';
    const gridColor = isDark ? 'rgba(255,255,255,0.05)' : 'rgba(26,35,64,0.06)';
    const textColor = isDark ? '#94a3b8' : '#6b7a9a';

    const gradient = earningsCtx.createLinearGradient(0, 0, 0, 280);
    gradient.addColorStop(0, 'rgba(46,196,182,0.35)');
    gradient.addColorStop(1, 'rgba(46,196,182,0.01)');

    if (earningsChart) earningsChart.destroy();

    earningsChart = new Chart(earningsCtx, {
      type: 'line',
      data: {
        labels,
        datasets: [{
          label: type === 'daily' ? 'Daily Earnings ($)' : 'Cumulative Profit ($)',
          data,
          borderColor: '#2ec4b6',
          borderWidth: 2.5,
          backgroundColor: gradient,
          fill: true,
          tension: 0.45,
          pointBackgroundColor: '#2ec4b6',
          pointBorderColor: '#fff',
          pointBorderWidth: 2,
          pointRadius: 4,
          pointHoverRadius: 6,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: isDark ? '#1e293b' : '#fff',
            borderColor: '#2ec4b6',
            borderWidth: 1,
            titleColor: isDark ? '#e2e8f0' : '#1a2340',
            bodyColor: '#2ec4b6',
            padding: 12,
            cornerRadius: 10,
            callbacks: {
              label: ctx => ' $' + ctx.parsed.y.toFixed(2),
            },
          },
        },
        scales: {
          x: {
            grid: { color: gridColor },
            ticks: { color: textColor, font: { size: 11, family: 'Inter' } },
          },
          y: {
            grid: { color: gridColor },
            ticks: {
              color: textColor,
              font: { size: 11, family: 'Inter' },
              callback: v => '$' + v.toFixed(0),
            },
          },
        },
      },
    });
  }

  renderEarningsChart('daily');

  document.querySelectorAll('.ec-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.ec-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      renderEarningsChart(tab.dataset.chart);
    });
  });

  // Re-render chart on theme change
  const themeObserver = new MutationObserver(() => {
    const activeTab = document.querySelector('.ec-tab.active');
    if (activeTab) renderEarningsChart(activeTab.dataset.chart);
  });
  themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });

  /* ===========================
     AOS INIT
  =========================== */
  if (typeof AOS !== 'undefined') {
    AOS.init({ duration: 700, once: true, offset: 60 });
  }

});
